import os
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker as ticker
from matplotlib import font_manager

# 设置更专业的字体和样式
plt.style.use('seaborn-v0_8-whitegrid')
mpl.rcParams['font.family'] = ['Times New Roman', 'DejaVu Sans', 'Arial']
mpl.rcParams['font.size'] = 11
mpl.rcParams['axes.linewidth'] = 1.2
mpl.rcParams['axes.labelsize'] = 12
mpl.rcParams['xtick.labelsize'] = 10
mpl.rcParams['ytick.labelsize'] = 10
mpl.rcParams['legend.fontsize'] = 10
mpl.rcParams['figure.dpi'] = 300
mpl.rcParams['savefig.dpi'] = 300
mpl.rcParams['savefig.bbox'] = 'tight'

# 数据设置
x = [2, 3, 4, 5, 6]
y_ours = [67.5,68.0,69.2,70.8,72.4]
y_llm = [68.2,68.4,69.0,69.8,71.1]  # LLM-MO数据
y_std = [121.2, 127.2, 134.6, 137.4, 147.9]

# 创建更大的画布以提供更好的视觉效果
fig, ax = plt.subplots(figsize=(6.4, 4.8), dpi=300)

# 更专业的颜色方案
color_ours = "#2E86C1"   # 专业蓝色 - Ours
color_llm = "#ED7D31"    # 橙色 - LLM-MO
color_std = "#28B463"    # 绿色 - Standard

# 绘制三组柱状图，增强视觉效果
bar_width = 0.25  # 减小柱子宽度以容纳三组
x_index = np.arange(len(x))

bars_ours = ax.bar(x_index - bar_width, y_ours, bar_width, 
                   color=color_ours, edgecolor='white', linewidth=1.5,
                   alpha=0.9, label='SCA', zorder=3, bottom=0)
bars_llm = ax.bar(x_index, y_llm, bar_width, 
                  color=color_llm, edgecolor='white', linewidth=1.5,
                  alpha=0.9, label='LLM-MO', zorder=3, bottom=0)
bars_std = ax.bar(x_index + bar_width, y_std, bar_width, 
                  color=color_std, edgecolor='white', linewidth=1.5,
                  alpha=0.9, label='Standard', zorder=3, bottom=0)

# # 为柱状图添加数值标签
# for i, (obs_val, std_val) in enumerate(zip(y_obs, y_std)):
#     # Ours标签
#     ax.text(i - bar_width/2, obs_val + 2, f'{obs_val}',
#             ha='center', va='bottom', fontsize=9, fontweight='bold')
#     # Standard标签  
#     ax.text(i + bar_width/2, std_val + 2, f'{std_val:.1f}',
#             ha='center', va='bottom', fontsize=9, fontweight='bold')

# 改进的样式设置 - 显示所有边框
ax.spines['top'].set_visible(True)
ax.spines['right'].set_visible(True)
ax.spines['left'].set_linewidth(1.2)
ax.spines['bottom'].set_linewidth(1.2)
ax.spines['top'].set_linewidth(1.2)
ax.spines['right'].set_linewidth(1.2)
ax.spines['left'].set_color('#2C3E50')
ax.spines['bottom'].set_color('#2C3E50')
ax.spines['top'].set_color('#2C3E50')
ax.spines['right'].set_color('#2C3E50')

# 更精细的网格设置
ax.grid(True, linestyle='--', linewidth=0.8, alpha=0.6, color='#BDC3C7', zorder=1)
ax.set_axisbelow(True)

# 坐标轴设置，增加更好的标签
ax.set_xlabel("Number of Vehicles", fontsize=13, fontweight='bold', color='#2C3E50')
ax.set_ylabel("Age of Information (ms)", fontsize=13, fontweight='bold', color='#2C3E50')

# 改进刻度设置
ax.tick_params(axis='both', labelsize=11, colors='#2C3E50', width=1.2)
ax.tick_params(axis='x', length=6, which='major')
ax.tick_params(axis='y', length=6, which='major')

# 设置x轴刻度和标签
ax.set_xticks(x_index)
ax.set_xticklabels([str(val) for val in x])

# 设置y轴范围，确保底部边框完整显示
y_min = min(min(y_ours), min(y_llm), min(y_std))
y_max = max(max(y_ours), max(y_llm), max(y_std))
y_range = y_max - y_min
# 确保柱子底部对齐到坐标轴边框
y_min_expanded = 0  # 严格从0开始
y_max_expanded = 150 
ax.set_ylim(y_min_expanded, y_max_expanded)

# 确保坐标轴底部边框在柱子之上显示
ax.axhline(y=0, color='#2C3E50', linewidth=1.2, zorder=5)

# 重新设置底部边框，确保它在最上层
ax.spines['bottom'].set_zorder(5)

# 格式化y轴刻度
ax.yaxis.set_major_formatter(ticker.FormatStrFormatter('%.1f'))

# 专业的图例设置
legend = ax.legend(
    fontsize=10,
    frameon=True,
    framealpha=0.95,
    edgecolor='#2C3E50',
    fancybox=True,
    shadow=True,
    loc='lower left',
    handlelength=2.5,
    handletextpad=0.8
)
legend.get_frame().set_facecolor('#F8F9FA')
legend.get_frame().set_linewidth(1.2)

# # 添加标题，使图表更完整
# ax.set_title('Age of Information Vs Number of Vehicles', 
#              fontsize=14, fontweight='bold', color='#2C3E50', pad=20)

# 保存图片，支持多种格式
desktop_path = os.path.expanduser("~") + "/Desktop"

# 调整布局，确保所有元素都能完整显示
plt.tight_layout()

# 保存高质量图片
plt.savefig(os.path.join(desktop_path, "8aoi_number_optimized.pdf"),
            format='pdf',
            transparent=False, 
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            dpi=300)

plt.savefig(os.path.join(desktop_path, "8aoi_number_optimized.png"),
            format='png',
            transparent=False, 
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            dpi=300)

print("AOI车辆数量对比图表已保存到桌面：aoi_number_optimized.pdf 和 aoi_number_optimized.png")

plt.show()