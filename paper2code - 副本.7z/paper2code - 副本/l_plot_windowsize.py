import os
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker as ticker
import matplotlib.gridspec as gridspec
from matplotlib import font_manager

# 设置更专业的字体和样式
plt.style.use('seaborn-v0_8-whitegrid')
mpl.rcParams['font.family'] = ['Times New Roman', 'DejaVu Sans', 'Arial']
mpl.rcParams['font.size'] = 11
mpl.rcParams['axes.linewidth'] = 1.2
mpl.rcParams['axes.labelsize'] = 12
mpl.rcParams['xtick.labelsize'] = 10
mpl.rcParams['ytick.labelsize'] = 10
mpl.rcParams['legend.fontsize'] = 10
mpl.rcParams['figure.dpi'] = 300
mpl.rcParams['savefig.dpi'] = 300
mpl.rcParams['savefig.bbox'] = 'tight'
#1、设置数据
x = [22.5,23,23.5,24,24.5,25,25.5,26]

# 窗口大小数据 - SCA方法
sca_data = {
    "SCA Line 1": [120,105,97,90,81,74,68,62],    # 慢速线路
    "SCA Line 2": [83,77,72,64,58,53,49,45],     # 中速线路
    "SCA Line 3": [55,48,42,38,35,33,29,28]      # 快速线路
}

# LLM-MO方法数据
llm_data = {
    "LLM-MO Line 1": [124,111,102,84,82,75,64,62],    # 慢速线路 - 比SCA稍好
    "LLM-MO Line 2": [87,83,74,73,64,52,47,43],     # 中速线路 - 比SCA稍好
    "LLM-MO Line 3": [52,45,46,40,32,30,29,25]      # 快速线路 - 比SCA稍好
}

# 创建更大的画布以提供更好的视觉效果
fig, ax = plt.subplots(figsize=(6.4, 4.8), dpi=300)

# 专业的颜色方案 - 为SCA和LLM-MO使用不同的颜色
sca_colors = ["#2E86C1", "#E74C3C", "#28B463"]  # 蓝色、红色、绿色 - SCA方法
llm_colors = ["#9B59B6", "#F39C12", "#1ABC9C"]  # 紫色、橙色、青色 - LLM-MO方法

# 标记样式 - SCA和LLM-MO使用不同的标记
sca_markers = ["o", "s", "^"]    # 圆形、方形、三角形 - SCA
llm_markers = ["D", "v", "p"]    # 菱形、下三角、五角星 - LLM-MO
marker_sizes = [8, 7, 8]     # 不同大小的标记

# 绘制SCA方法的线
for idx, (line_name, y_values) in enumerate(sca_data.items()):
    color = sca_colors[idx]
    marker = sca_markers[idx]
    marker_size = marker_sizes[idx]
    
    # 根据速度特性选择标签
    if idx == 0:
        label = f"{line_name} (Slow)"
    elif idx == 1:
        label = f"{line_name} (Medium)"
    else:
        label = f"{line_name} (Fast)"
    
    ax.plot(x, y_values,
            color=color,
            marker=marker,
            markersize=marker_size,
            markerfacecolor="white",
            markeredgecolor=color,
            markeredgewidth=2,
            linewidth=2.5,
            alpha=0.9,
            label=label,
            zorder=3)

# 绘制LLM-MO方法的线
for idx, (line_name, y_values) in enumerate(llm_data.items()):
    color = llm_colors[idx]
    marker = llm_markers[idx]
    marker_size = marker_sizes[idx]
    
    # 根据速度特性选择标签
    if idx == 0:
        label = f"{line_name} (Slow)"
    elif idx == 1:
        label = f"{line_name} (Medium)"
    else:
        label = f"{line_name} (Fast)"
    
    ax.plot(x, y_values,
            color=color,
            marker=marker,
            markersize=marker_size,
            markerfacecolor="white",
            markeredgecolor=color,
            markeredgewidth=2,
            linewidth=2.5,
            alpha=0.9,
            label=label,
            zorder=3)

# 改进的样式设置 - 显示所有边框
ax.spines['top'].set_visible(True)
ax.spines['right'].set_visible(True)
ax.spines['left'].set_linewidth(1.2)
ax.spines['bottom'].set_linewidth(1.2)
ax.spines['top'].set_linewidth(1.2)
ax.spines['right'].set_linewidth(1.2)
ax.spines['left'].set_color('#2C3E50')
ax.spines['bottom'].set_color('#2C3E50')
ax.spines['top'].set_color('#2C3E50')
ax.spines['right'].set_color('#2C3E50')

# 更精细的网格设置
ax.grid(True, linestyle='--', linewidth=0.8, alpha=0.6, color='#BDC3C7', zorder=1)
ax.set_axisbelow(True)

# 坐标轴设置，增加更好的标签
ax.set_xlabel("Average Speed (m/s)", fontsize=13, fontweight='bold', color='#2C3E50')
ax.set_ylabel("Window Size (ms)", fontsize=13, fontweight='bold', color='#2C3E50')

# 改进刻度设置
ax.tick_params(axis='both', labelsize=11, colors='#2C3E50', width=1.2)
ax.tick_params(axis='x', length=6, which='major')
ax.tick_params(axis='y', length=6, which='major')
ax.tick_params(axis='x', length=3, which='minor')
ax.tick_params(axis='y', length=3, which='minor')

# 设置x轴刻度，更清晰的间隔
ax.set_xticks(x)
ax.set_xlim(22.25, 26.25)  # 给图表边缘留出一些空间

# 设置y轴范围，让数据更突出
sca_y_values = [val for values in sca_data.values() for val in values]
llm_y_values = [val for values in llm_data.values() for val in values]
y_values_all = sca_y_values + llm_y_values
y_min, y_max = min(y_values_all), max(y_values_all)
margin = (y_max - y_min) * 0.1
ax.set_ylim(y_min - margin, y_max + margin)

# 专业的图例设置 - 调整位置以适应更多线条
legend = ax.legend(
    fontsize=9,
    frameon=True,
    framealpha=0.95,
    edgecolor='#2C3E50',
    fancybox=True,
    shadow=True,
    loc='upper right',
    bbox_to_anchor=(0.98, 0.98),
    handlelength=2.5,
    handletextpad=0.5,
    ncol=2  # 两列显示
)
legend.get_frame().set_facecolor('#F8F9FA')
legend.get_frame().set_linewidth(1.2)

# # 添加标题，使图表更完整
# ax.set_title('Window Size vs Average Speed', 
#              fontsize=14, fontweight='bold', color='#2C3E50', pad=20)

# 保存图片，支持多种格式
desktop_path = os.path.expanduser("~") + "/Desktop"

# 调整布局，确保所有元素都能完整显示
plt.tight_layout()

# 保存高质量图片
plt.savefig(os.path.join(desktop_path, "1windowsize_optimized.pdf"),
            format='pdf',
            transparent=False, 
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            dpi=300)

plt.savefig(os.path.join(desktop_path, "1windowsize_optimized.png"),
            format='png',
            transparent=False, 
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            dpi=300)

print("图表已保存到桌面：1windowsize_optimized.pdf 和 1windowsize_optimized.png")
plt.show()


