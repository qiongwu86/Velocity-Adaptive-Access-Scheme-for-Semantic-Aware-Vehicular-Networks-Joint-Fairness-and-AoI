import os
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker as ticker
import matplotlib.gridspec as gridspec
from matplotlib import font_manager

# 设置更专业的字体和样式
plt.style.use('seaborn-v0_8-whitegrid')
mpl.rcParams['font.family'] = ['Times New Roman', 'DejaVu Sans', 'Arial']
mpl.rcParams['font.size'] = 11
mpl.rcParams['axes.linewidth'] = 1.2
mpl.rcParams['axes.labelsize'] = 12
mpl.rcParams['xtick.labelsize'] = 10
mpl.rcParams['ytick.labelsize'] = 10
mpl.rcParams['legend.fontsize'] = 10
mpl.rcParams['figure.dpi'] = 300
mpl.rcParams['savefig.dpi'] = 300
mpl.rcParams['savefig.bbox'] = 'tight'

#1、设置数据
x = [22.5,23,23.5,24,24.5,25,25.5,26]

# SCA方法数据
sca_data = {
    # "Line 1": [0.009, 0.012, 0.014, 0.017, 0.021, 0.027, 0.033, 0.038],  # 注释掉1号线数据
    "Line 2": [0.005, 0.008, 0.009, 0.014, 0.019, 0.023, 0.027, 0.034],
    "Line 3": [0.007, 0.011, 0.015, 0.019, 0.024, 0.029, 0.035, 0.041]
}

# LLM-MO方法数据
llm_data = {
    # "Line 1": [0.011, 0.016, 0.021, 0.026, 0.031, 0.034, 0.038, 0.043],  # 注释掉1号线数据
    "Line 2": [0.007, 0.014, 0.017, 0.021, 0.026, 0.029, 0.033, 0.039],
    "Line 3": [0.0010, 0.015, 0.022, 0.024, 0.029, 0.030, 0.040, 0.045]
}

# 标准方法数据
std_data = {
    # "Line 1": [0.052, 0.069, 0.074, 0.093, 0.13, 0.18, 0.21, 0.24],  # 注释掉1号线数据
    "Line 2": [0.042, 0.060, 0.071, 0.087, 0.11, 0.14, 0.17, 0.20],
    "Line 3": [0.050, 0.067, 0.077, 0.098, 0.14, 0.17, 0.22, 0.25]
}

# SCA方法数据
sca_data = {
    # "Line 1": [0.009, 0.012, 0.014, 0.017, 0.021, 0.027, 0.033, 0.038],  # 注释掉1号线数据
    "Line 2": [0.005, 0.008, 0.009, 0.014, 0.019, 0.023, 0.027, 0.034],
    "Line 3": [0.007, 0.011, 0.015, 0.019, 0.024, 0.029, 0.035, 0.041]
}

# LLM-MO方法数据
llm_data = {
    # "Line 1": [0.012, 0.014, 0.017, 0.015, 0.024, 0.029, 0.037, 0.041],  # 注释掉1号线数据
    "Line 2": [0.007, 0.010, 0.015, 0.019, 0.024, 0.026, 0.032, 0.036],
    "Line 3": [0.009, 0.014, 0.017, 0.022, 0.026, 0.031, 0.037, 0.042]
}

# 标准方法数据
std_data = {
    # "Line 1": [0.052, 0.069, 0.074, 0.093, 0.13, 0.18, 0.21, 0.24],  # 注释掉1号线数据
    "Line 2": [0.042, 0.060, 0.071, 0.087, 0.11, 0.14, 0.17, 0.20],
    "Line 3": [0.050, 0.067, 0.077, 0.098, 0.14, 0.17, 0.22, 0.25]
}

# 创建更大的画布以提供更好的视觉效果
fig, ax = plt.subplots(figsize=(6.4, 4.8), dpi=300)

# 原来的配色方案 - 每个Line使用一种颜色
base_colors = {
    "Line 1": "#2E86C1",  # 蓝色
    "Line 2": "#E74C3C",  # 红色
    "Line 3": "#28B463"   # 绿色
}

# 三种方法使用不同的颜色
method_colors = {
    "SCA": "#2E86C1",      # 蓝色 - SCA方法
    "LLM-MO": "#ED7D31",      # 红色 - LLM方法
    "Standard": "#28B463"  # 绿色 - 标准方法
}

# 两种Line使用不同的线型
line_styles = {
    "Line 2": "-",          # 实线 - Line 2
    "Line 3": "--"          # 虚线 - Line 3
}

# 标记样式
line_markers = {
    "Line 2": "o",          # 圆形标记 - Line 2
    "Line 3": "s"           # 方形标记 - Line 3
}

# 设置柱状图参数
bar_width = 0.06  # 单个柱子的宽度 - 稍微减小
group_spacing = 0.05  # 组间距 - 大幅减小，几乎没有间隔
n_methods = 3  # SCA, LLM, Standard
n_vehicles = 2  # Line 1, Line 3 (移除了Line 2)

# 计算每组的起始位置
x_ticks = np.arange(len(x))

# 绘制线图
for method_name, method_data in [("SCA", sca_data), ("LLM-MO", llm_data), ("Standard", std_data)]:
    color = method_colors[method_name]
    for vehicle_name, y_values in method_data.items():
        linestyle = line_styles[vehicle_name]
        marker = line_markers[vehicle_name]

        ax.plot(x, y_values,
                color=color,
                linestyle=linestyle,
                marker=marker,
                markersize=8,
                markerfacecolor="white",
                markeredgecolor=color,
                markeredgewidth=2,
                linewidth=2.5,
                alpha=0.9,
                label=f'{vehicle_name} ({method_name})',
                zorder=3)

# 更精细的网格设置
ax.grid(True, linestyle='--', linewidth=0.8, alpha=0.6, color='#BDC3C7', zorder=1)
ax.set_axisbelow(True)

# 改进的样式设置 - 显示所有边框
ax.spines['top'].set_visible(True)
ax.spines['right'].set_visible(True)
ax.spines['left'].set_linewidth(1.2)
ax.spines['bottom'].set_linewidth(1.2)
ax.spines['top'].set_linewidth(1.2)
ax.spines['right'].set_linewidth(1.2)
ax.spines['left'].set_color('#2C3E50')
ax.spines['bottom'].set_color('#2C3E50')
ax.spines['top'].set_color('#2C3E50')
ax.spines['right'].set_color('#2C3E50')

# 坐标轴设置，增加更好的标签
ax.set_xlabel("Average Speed (m/s)", fontsize=13, fontweight='bold', color='#2C3E50')
ax.set_ylabel("Objective Value", fontsize=13, fontweight='bold', color='#2C3E50')

# 改进刻度设置
ax.tick_params(axis='both', labelsize=11, colors='#2C3E50', width=1.2)
ax.tick_params(axis='x', length=6, which='major')
ax.tick_params(axis='y', length=6, which='major')
ax.tick_params(axis='x', length=3, which='minor')
ax.tick_params(axis='y', length=3, which='minor')

# 设置x轴刻度和标签
ax.set_xticks(x)
ax.set_xlim(22.25, 26.25)  # 给图表边缘留出一些空间

# 设置y轴范围，让数据更突出
sca_y_values = [val for val in sca_data.values() for val in val]
llm_y_values = [val for val in llm_data.values() for val in val]
std_y_values = [val for val in std_data.values() for val in val]
all_y_values = sca_y_values + llm_y_values + std_y_values
y_min = min(all_y_values)
y_max = max(all_y_values)
margin = (y_max - y_min) * 0.1
ax.set_ylim(y_min - margin, y_max + margin)

# 格式化y轴刻度为小数
ax.yaxis.set_major_formatter(ticker.FormatStrFormatter('%.3f'))

# 专业的图例设置 - 显示线型和颜色的组合
legend = ax.legend(
    ncol=3,  # 3列布局
    fontsize=7,  # 合适的字体大小
    frameon=True,
    framealpha=0.95,
    edgecolor='#2C3E50',
    fancybox=True,
    shadow=True,
    loc='upper left',
    bbox_to_anchor=(0.02, 0.98),
    columnspacing=1.0,
    handlelength=4.0,  # 进一步增加手柄长度以更好地显示线型差异
    handletextpad=0.8
)

legend.get_frame().set_facecolor('#F8F9FA')
legend.get_frame().set_linewidth(1.2)

# # 添加标题，使图表更完整
# ax.set_title('Objective Value Vs Average Speed', 
#              fontsize=14, fontweight='bold', color='#2C3E50', pad=20)

# 保存图片，支持多种格式
desktop_path = os.path.expanduser("~") + "/Desktop"

# 调整布局，确保所有元素都能完整显示
plt.tight_layout()

# 保存高质量图片
plt.savefig(os.path.join(desktop_path, "2difference_optimized.pdf"),
            format='pdf',
            transparent=False, 
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            dpi=300)

plt.savefig(os.path.join(desktop_path, "2difference_optimized.png"),
            format='png',
            transparent=False, 
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            dpi=300)

print("图表已保存到桌面：2difference_optimized.pdf 和 2difference_optimized.png")
plt.show()