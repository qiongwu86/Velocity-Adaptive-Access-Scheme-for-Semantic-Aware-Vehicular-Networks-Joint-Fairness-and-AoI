import os

import numpy as np
from pymoo.termination import get_termination

from pymoo.algorithms.moo.moead import MOEAD
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.algorithms.moo.spea2 import SPEA2
from pymoo.algorithms.moo.moead_LLM import MOEAD_LLM
from pymoo.optimize import minimize
from pymoo.problems import get_problem
from problem_interface import RE

from pymoo.util.ref_dirs import get_reference_directions
from output import output
import matplotlib.pyplot as plt


def get_problem(problemname):
    if problemname == "vehicle":
        problem = RE(0)  # vehicle类在索引0
    elif problemname == "FairnessAndAoI":
        problem = RE(1)  # FairnessAndAoI类在索引1
    elif problemname == "RE21":
        problem = RE(2)  # RE21类在索引2
    else:
        raise ValueError(f"Unknown problem: {problemname}")
    return problem

def get_algorithm(algorithmname, pop_size, ref_dirs=None, neighbor_size=20):
    if algorithmname == "MOEAD":
        algorithm = MOEAD(
            ref_dirs,
            n_neighbors=neighbor_size,
            prob_neighbor_mating=0.9,
        )
    elif algorithmname == "NSGAII":
        algorithm = NSGA2(pop_size=pop_size)
    elif algorithmname == "NSGAIII":
        algorithm = NSGA3(pop_size=pop_size, ref_dirs=ref_dirs)
    elif algorithmname == "SPEA2":
        algorithm = SPEA2(pop_size=pop_size)
    elif algorithmname == "MOEAD_LLM":
        algorithm = MOEAD_LLM(
            ref_dirs,
            n_neighbors=neighbor_size,
            prob_neighbor_mating=0.7,
            debug_mode = debug_mode,
            model_LLM = model_LLM,
            endpoint = endpoint,
            key = key,
            out_file = out_filename_gpt,
        )
    else:
        raise ValueError(f"Unknown algorithm: {algorithmname}")
    
    return algorithm


if __name__ == '__main__':

    # 算法配置
    algorithmname = "MOEAD_LLM"  # NSGAII, MOEAD, NSGAIII, SPEA2, MOEAD_LLM
    record_gpt_solution = False # record the input and oupt of each run of gpt to learn a general linear operator
    model_LLM = "deepseek-v3-250324"
    endpoint ="https://ark.cn-beijing.volces.com/api/v3"
    key="91584f99-d2d6-4975-93ed-61c73bf38a5d"
    debug_mode = False
    # 参数设置
    pop_size = 100
    neighbor_size = 20
    n_gen = 300
    n_partition = 10
    dimension = 3  # w[0], w[1], w[2]
    
    # 问题配置
    problems = ['FairnessAndAoI']
    n_repeat = 1
    
    for prob in problems:
        for n in range(n_repeat):
            
            problemname = prob
            
            # 创建输出目录
            outputfile = problemname + "/results" + str(n) + "/"
            outputfile = problemname+"/results"+str(n)+"/"

            if record_gpt_solution:
                out_filename_gpt=outputfile+problemname+"_d"+str(dimension)+"_gpt_sample.dat"
                file = open (out_filename_gpt,"w")
                file.close()
            else:
                out_filename_gpt= None
            os.makedirs(outputfile, exist_ok=True)
            
            # 生成参考方向（仅对需要的算法）
            if algorithmname in ["MOEAD", "NSGAIII", "MOEAD_LLM"]:
                ref_dirs = get_reference_directions("das-dennis", 4, n_partitions=n_partition)  # 4个目标
            else:
                ref_dirs = None
            
            # 获取问题和算法实例
            problem = get_problem(problemname)
            print(f"Problem: {problem}")
            
            algorithm = get_algorithm(algorithmname, pop_size, ref_dirs, neighbor_size)
            print(f"Algorithm: {algorithmname}")
            
            # 设置终止条件
            termination = get_termination("n_gen", n_gen)
            
            # 运行优化
            print(f"\n开始优化求解 (算法: {algorithmname}, 种群: {pop_size}, 代数: {n_gen})...")
            res = minimize(
                problem,
                algorithm,
                termination=termination,
                save_history=True,
                verbose=True
            )
            
            print("Shape of Pareto front:", res.F.shape)
            print("Pareto front F:", res.F)
            print("Pareto front X:", res.X)
            
            # 保存结果
            output(res, problemname, dimension, outputfile)

