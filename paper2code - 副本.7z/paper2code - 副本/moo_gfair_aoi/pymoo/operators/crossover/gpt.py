import numpy as np

from pymoo.core.crossover import Crossover
from pymoo.util.misc import crossover_mask
import json
import http.client
import re
import time
from openai import OpenAI
#from volcenginesdkarkruntime import Ark
class GPT(Crossover):

    def __init__(self, n_new, **kwargs):
        super().__init__(10, 2, **kwargs)
        self.n_new = n_new

    def get_prompt(self, x, y, obj_p):
        # Convert given individuals to the desired string format
        #print(x)
        pop_content = " "
        for i in range(len(x)):
            # pop_content+="point: <start>"+",".join(str(idx) for idx in x[i].tolist())+"<end> \n value: "+str(y[i])+" objective 1: "+str(obj_p[i][0])+" objective 2: "+str(obj_p[i][1])+"\n\n"
            pop_content += "point: <start>" + ",".join(
                str(idx) for idx in x[i].tolist()) + "<end> \n objective 1: " + str(
                round(obj_p[i][0], 4)) + " objective 2: " + str(round(obj_p[i][1], 4)) + " objective 3: " + str(round(obj_p[i][2], 4))+ " objective 4: " + str(round(obj_p[i][3], 4))+"\n\n"
        #print(pop_content)
        prompt_content = "现在你要帮助我优化" + str(len(x[0])) + "变量的"+ str(len(obj_p[0])) + "目标问题” “我有一些解和他们的目标值” 这些点以<start>开始以<end>结束.\n\n" \
                         + pop_content \
                         + "给我两个不同于上面所有解的新解, 生成的新解应在至少一个目标上优于现有解. 不必给出任何解释，直接输出结果. 每个新解以<start>开始以<end>结束"
        return prompt_content

    def _do(self, _, X, Y, debug_mode, model_LLM, endpoint, key, out_filename, parents_obj, max_retries=5,**kwargs,):
        retries = 0

        while retries < max_retries:
            try:

                # x_scale = 1000.0
                y_p = np.zeros(len(Y))
                x_p = np.zeros((len(X), len(X[0][0])))
                for i in range(len(Y)):
                    y_p[i] = round(Y[i][0][0], 4)
                    x_p[i] = X[i][0]

                    x_p[i] = np.round((x_p[i] - _.xl) / (_.xu - _.xl), 4)

                # x_p = x_scale*x_p

                sort_idx = sorted(range(len(Y)), key=lambda k: Y[k], reverse=True)
                x_p = [x_p[idx] for idx in sort_idx]
                y_p = [y_p[idx] for idx in sort_idx]
                obj_p = parents_obj[0][:10].get("F")
                obj_p = [obj_p[idx] for idx in sort_idx]

                prompt_content = self.get_prompt(x_p, y_p, obj_p)
                client = OpenAI(
                    api_key=key,
                    base_url=endpoint,
                )

                #print("----- standard request -----")
                completion = client.chat.completions.create(
                    # "model": "gpt-3.5-turbo",
                    # "model": "gpt-4-0613",
                    model=model_LLM,
                    messages=[
                         {"role": "user","content": prompt_content},

                    ],
                )
                response=completion.choices[0].message.content
                matches = re.findall(r"<start>(.*?)<end>", response)
                if len(matches) >= 2:
                    #print("成功生成满足条件的响应：")
                    #print(response)
                    off_string1 = re.findall(r"<start>(.*?)<end>", response)[0]
                    off1 = np.fromstring(off_string1, sep=",", dtype=float)

                    off_string2 = re.findall(r"<start>(.*?)<end>", response)[1]
                    off2 = np.fromstring(off_string2, sep=",", dtype=float)

                    # if out_filename != None:
                    #     filename = out_filename
                    #     file = open(filename, "a")
                    #     for i in range(len(x_p)):
                    #         for j in range(len(x_p[i])):
                    #             file.write("{:.4f} ".format(x_p[i][j]))
                    #         file.write("{:.4f} ".format(y_p[i]))
                    #     for i in range(len(off1)):
                    #         file.write("{:.4f} ".format(off1[i]))
                    #     for i in range(len(off1)):
                    #         file.write("{:.4f} ".format(off2[i]))
                    #     # file.write("{:.4f} {:.4f} {:.4f} {:.4f} \n".format(off1[0],off1[1],off[1][0][0],off[1][0][1]))
                    #     file.write("\n")
                    #     file.clos
                    off1[np.where(off1 < 0)] = 0.0
                    off1[np.where(off1 > 1)] = 1.0
                    off2[np.where(off2 < 0)] = 0.0
                    off2[np.where(off2 > 1)] = 1.0
                    off1 = np.array([[(off1 * (_.xu - _.xl) + _.xl)]])
                    off2 = np.array([[(off2 * (_.xu - _.xl) + _.xl)]])
                    off = np.append(off1, off2, axis=0)

                    #break
                    print('off:',off )
                    #print(f"Generated offspring (normalized): {off}")  # 检查是否在 [0,1] 范围内
                    return off
                else:
                    print(f"响应中仅找到 {len(matches)} 个匹配项，重试中...")
                    retries += 1
                    time.sleep(1)  # 避免频繁调用

            except Exception as e:
                print(f"API 调用失败: {e}")
                retries += 1
                time.sleep(2)

            raise Exception(f"超过最大重试次数 {max_retries}，仍未满足条件")






class GPT_interface(GPT):

    def __init__(self, **kwargs):
        super().__init__(n_new=1, **kwargs)
