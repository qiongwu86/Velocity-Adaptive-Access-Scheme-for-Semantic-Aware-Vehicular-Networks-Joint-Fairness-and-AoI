#!/usr/bin/env python

import random
from idlelib.pyparse import C_NONE

import numpy as np
import math

from scipy.integrate import tplquad
# 导入我们的计算模块
from Gfair import calculate_Gfair
from aoi import compute_aoi
from param import params


class vehicle:
    def __init__(self):
        self.V2I_Shadowing = None
        self.V2I_pathloss = None
        self.platoon_V2I_Signal = None
        self.delta_distance = None
        self.problem_name = 'vehicle'
        self.n_objectives = 3 #目标函数+1，为约束
        self.n_variables = 2  #车辆数
        self.n_constraints = 0
        self.n_original_constraints = 3


#窗口大小的上下界
        self.ubound = np.full(self.n_variables, 97.75)
        self.lbound = np.full(self.n_variables,7.75)

        self.sig2_dB = -114
        self.bsAntGain = 8
        self.vehAntGain = 3
        self.bsNoiseFigure = 5
        self.vehNoiseFigure = 9
        self.sig2 = 10 ** (self.sig2_dB / 10)
        self.p0 = 30      #1w
        # self.n_RB = n_RB
        self.time_fast = 0.001
        self.time_slow = 0.1  # update slow fading/vehicle position every 100 ms
        self.bandwidth = 20000000  # bandwidth per RB, 180,000 MHz

        self.h_bs = 25
        self.h_ms = 1.5

        self.shadow_std = 8
        self.Decorrelation_distance = 50

    def evaluate(self, x):
        f = np.zeros(self.n_objectives)
        g = np.zeros(self.n_original_constraints)

        return f
class FairnessAndAoI():
    def __init__(self):
        """
        初始化优化问题参数
        :param num_vehicles: 车辆数量 N
        :param bandwidth: 系统带宽
        :param transmission_power: 传输功率
        :param noise_power: 噪声功率
        :param v_min: 车辆最小速度
        :param v_max: 车辆最大速度
        """


        self.rho = 1
        self.problem_name = "FairnessAndAoI"
        self.num_vehicles = 3  # 车辆数量
        self.n_objectives = 4   # 多目标数量
        self.n_variables = 3  # 优化变量数量 (每辆车的窗口大小)
        self.n_constraints = 0
        self.all_num_vehicles = 3  # 总共车辆数量

        self.bandwidth = 10e6
        self.transmission_power = [1,1.2,1.5]
        self.noise_power = 1e-9
        self.v_min = 10
        self.v_max = 40
        self.Range= 200    #RSU覆盖范围，待定

        self.tau=[10,10,10]

        self.N_Ca = 5
        self.C_Ca = 50
        self.RRI = 0.5
        self.dis=[15,13,17]
        #self.dis = [15, 25]
        self.nsh=55
        self.tp = 2.5
        self.tfa = random.uniform(0.0625, 1)
        # 窗口大小的上下界
        self.lbound = np.full(self.n_variables, 20)  # 窗口大小下界
        self.ubound = np.full(self.n_variables, 150)  # 窗口大小上界
        #self.lbound= np. array([20, 20, 300])
        #self.ubound = np.array([150, 150, 600])
        #x=[1270,1360,450]
        # 初始化车辆速度
        #self.vehicle_speeds = np.random.uniform(self.v_min, self.v_max, self.num_vehicles)

        self.vehicle_speeds=[20,22,24]

    def calculate_bitrate(self,i):
            # 计算车辆 i 的传输数据量
        rate = np.log2(1 + (self.transmission_power[i] * self.calculate_h(i)*(self.dis[i]**-2 )/ self.noise_power))

        return rate
    def calculate_fairness(self, x):
        """
        计算每辆车的公平性指标和整体网络公平性
        :param x: 决策变量，每辆车的选择窗口大小
        :return: 每辆车的公平性指标数组和整体网络公平性
        """

        fairness_per_vehicle = []
        error2=1
        #bitrate=[]
        # 计算每辆车的公平性指标
        for i in range(self.num_vehicles):
            vi = self.vehicle_speeds[i]  # 每辆车的速度
            #T_i = self.Range / vi  # 覆盖时间

            # 计算车辆 i 的传输数据量
            rate = self.calculate_bitrate(i)

            Pcol= self.calculate_p_error(i, x)
            #print(Pcol)
            bit_i=  rate* Pcol
            #print(bit_i)
            fairness_per_vehicle.append(bit_i / vi)  #
       # print('Pcol_suc=',fairness_per_vehicle)
        # 计算整体网络公平性 (使用平均速度和窗口大小)
        # avg_speed = np.mean(self.vehicle_speeds)  # 平均速度
        # avg_window_size = [np.mean(x),np.mean(x),np.mean(x)]  # 平均窗口大小
        # rate1 = self.calculate_bitrate(1)
        # Pcol1 = self.calculate_p_error(1, avg_window_size)
        # bit1 = rate1 * Pcol1
        # network_fairness=bit1/avg_speed

        network_fairness = np.mean(fairness_per_vehicle)
        #network_fairness=1
        return fairness_per_vehicle, network_fairness

    def calculate_age(self, x):
        """
        计算系统的信息年龄目标（基于公式 38 和公式 39）
        :param x: 决策变量，每辆车的选择窗口大小
        :return: 系统平均信息年龄
        """
        system_age = 0  # 系统总信息年龄

        interference_sum = self.calculate_p(0, 1, x) + self.calculate_p(1, 0, x)
        for k in range(self.num_vehicles):

            H_k = self.calculate_H(k, x)
            R_k = self.calculate_R(k, x)
            S = []
            sum_p1 = 0
            for j in range(0, self.num_vehicles-1):  # j ranges from 1 to N-1
                if j != k:
                    sum_p1 += self.calculate_p(k, j, x)

            # 第一部分
            term_1 = H_k - sum_p1
            term_2 = H_k * R_k

            # 第二部分 (求和项)
            term_3 = 0
            sum_p2= 0
            for q in range(self.num_vehicles):
                H_q = self.calculate_H(q, x)
                R_q = self.calculate_R(q, x)
                for j in range(self.num_vehicles-1):
                    if j != q:
                        sum_p2 += self.calculate_p(q, j, x)

                term_3 += R_q / (H_q - sum_p2)

            # 第三部分 (干扰加权项)
            term_4 = 0
            for q in range(self.num_vehicles):
                if q != k:
                    H_q = self.calculate_H(q, x)
                    paiq = self.calculate_pai(q, x)
                    term_4 += paiq / (H_q - interference_sum)

            # 汇总公式 38 的计算
            AoI_k = (term_1 / term_2) * (1 + term_3) + term_4
            system_age += AoI_k

        # 公式 39: 系统信息年龄为各车辆信息年龄的平均值
        system_age /= self.num_vehicles

        # print('system_age:', system_age)
        system_age = float(system_age)
        return abs(system_age)

    def calculate_pai(self,i,x):

        interference_sum = self.calculate_p(0, 1, x) + self.calculate_p(1, 0, x)
        term_4=0
        for q in range(self.num_vehicles):

            R_q = self.calculate_R(q, x)

            term_4 += R_q / (R_q - interference_sum)
        cr=1+term_4
        H_i = self.calculate_H(i, x)
        return self.calculate_R(i,x)/(cr*(H_i-interference_sum))

    def calculate_H(self, k,x):
        tw = x[k]
        ts = self.tp + self.tfa + tw
        tp=200/(self.calculate_bitrate(k)*self.bandwidth)
        H=1/(ts+tp)
        return H

    def calculate_R(self, k, x):
        tw = x[k]
        ts = self.tp + self.tfa + tw
        tp = 200 / (self.calculate_bitrate(k) * self.bandwidth)
        tr=2*(self.tp+self.tfa)+tw+2*tp
        ti=ts+tp
        tf=ti+32*tr
        R = 1 / tf
        return R

    def calculate_p(self, i,j, x):
        twi = x[i]
        twj = x[j]
        tsi = self.tp + self.tfa + twi
        tsj = self.tp + self.tfa + twj
        tpi = 200 / (self.calculate_bitrate(i) * self.bandwidth)
        tpj = 200 / (self.calculate_bitrate(j) * self.bandwidth)

        ti = tsi+tpi
        tj = tsj+tpj

        P = 1 / (ti+tj)
        return P


    def calculate_h(self, i):
        """
        计算信道增益 h(t)
        :param i: 车辆索引
        :return: 信道增益
        """
        h_prev = 1  # 初始化上一时刻的信道增益
        e_t = np.random.normal(0, 1)  # 高斯噪声
        h_t = self.rho * h_prev + e_t * np.sqrt(1 - self.rho**2)
        return h_t

    def calculate_p_error(self, i, x):
        """
        计算车辆 i 的传输失败概率
        :param i: 车辆索引
        :param x: 每辆车的窗口大小列表 (即 W_i)
        :return: 传输失败概率 P_error
        """
        num_vehicles = self.num_vehicles
        P_RR = 1  # 初始化成功概率
        delta_COL=1
        delta_HD=1
        P_O=1
        P_SHO=1
        for j in range(num_vehicles):
            if j != i:
                W_i, W_j = x[i], x[j]
                P_O = 2 * (W_i + 1) / (1000 + 2 * self.RRI)
                N_sh = (W_i + 1) * (W_j + 1) / (W_i + W_j + 1)  # 公式 14
            # 计算 δ^j_COL (公式 12)
            # W_i, W_j = x[i], x[j]
            # P_O = 2*(W_i + W_j + 1) / (1000 + 2 * self.RRI)  # 公式 12 中的 P_O
            #
            #
            #
            # N_sh = (W_i + 1) **2 / (2*W_i + 1)

                P_SHO = (N_sh*self.nsh )** 2 / self.bandwidth  # 公式 13

            # 冲突概率 δ^j_COL
            delta_COL_j = P_O * P_SHO * (self.C_Ca / self.N_Ca)/10000

            # 冲突概率 δ^j_HD（如适用，需明确定义）
            delta_HD_j = self.calculate_error2(self.tau[j])  # 示例，需补充公式

            delta_COL*=1 - delta_COL_j
            delta_HD *= 1 - delta_HD_j
                # 累乘概率项
        P_RR= delta_COL*delta_HD

        # # 引入额外因子 (10^-4)
        #P_RR *= 10 ** -4
        #
        #return delta_COL
        #print(P_RR)
        return P_RR

    def calculate_error2(self, tau):
        error2=tau/1000

        return error2


    def evaluate(self, x):
        """
        多目标优化评价函数
        :param x: 优化变量 (窗口大小向量)
        :return: 多目标优化的目标值数组
        """

        f = np.zeros(self.n_objectives)  # 多目标优化

        #vehicle_speeds=self.vehicle_speeds

        # 计算每辆车的公平性和整体网络的公平性
        fairness_objectives, network_fairness = self.calculate_fairness(x)

        # 前 N 个目标：每辆车公平性与网络公平性的绝对差值
        for k in range(self.num_vehicles):
            f[k] = np.abs(fairness_objectives[k] - network_fairness)

        # 第 N+1 个目标：网络的信息年龄
        f[self.num_vehicles] = self.calculate_age(x )


        return f



# 保持原有的其他类定义...
class FairnessAndAoI2():
    def __init__(self):
        """
        初始化优化问题参数
        :param num_vehicles: 车辆数量 N
        :param bandwidth: 系统带宽
        :param transmission_power: 传输功率
        :param noise_power: 噪声功率
        :param v_min: 车辆最小速度
        :param v_max: 车辆最大速度
        """


        self.rho = 1
        self.problem_name = "FairnessAndAoI2"
        self.num_vehicles = 3  # 车辆数量
        self.n_objectives = 4   # 多目标数量
        self.n_variables = 3  # 优化变量数量 (每辆车的窗口大小)
        self.n_constraints = 0
        self.all_num_vehicles = 3  # 总共车辆数量

        self.bandwidth = 10e6
        self.transmission_power = [1,1.2,1.5]
        self.noise_power = 1e-9
        self.v_min = 10
        self.v_max = 40
        self.Range= 200    #RSU覆盖范围，待定

        self.tau=[10,10,10]

        self.N_Ca = 5
        self.C_Ca = 50
        self.RRI = 0.5
        self.dis=[15,13,17]
        #self.dis = [15, 25]
        self.nsh=55
        self.tp = 2.5
        self.tfa = random.uniform(0.0625, 1)
        # 窗口大小的上下界
        self.lbound = np.full(self.n_variables, 20)  # 窗口大小下界
        self.ubound = np.full(self.n_variables, 150)  # 窗口大小上界

        self.vehicle_speeds=[20,22,24]

    def evaluate(self, x):
        # 简化的评价函数，可以根据需要补充
        f = np.zeros(self.n_objectives)
        return f


# 添加其他必需的类占位符以保持兼容性
class RE21:
    def __init__(self):
        self.problem_name = "RE21"
        self.n_objectives = 2
        self.n_variables = 4
        self.n_constraints = 0
        self.lbound = np.array([0.01, 0.01, 0.01, 0.01])
        self.ubound = np.array([100, 100, 100, 100])
    
    def evaluate(self, x):
        return np.zeros(self.n_objectives)

class RE22:
    def __init__(self):
        self.problem_name = "RE22"
        self.n_objectives = 2
        self.n_variables = 4
        self.n_constraints = 0
        self.lbound = np.array([0.01, 0.01, 0.01, 0.01])
        self.ubound = np.array([100, 100, 100, 100])
    
    def evaluate(self, x):
        return np.zeros(self.n_objectives)

class RE23:
    def __init__(self):
        self.problem_name = "RE23"
        self.n_objectives = 2
        self.n_variables = 4
        self.n_constraints = 0
        self.lbound = np.array([0.01, 0.01, 0.01, 0.01])
        self.ubound = np.array([100, 100, 100, 100])
    
    def evaluate(self, x):
        return np.zeros(self.n_objectives)

class RE24:
    def __init__(self):
        self.problem_name = "RE24"
        self.n_objectives = 2
        self.n_variables = 2
        self.n_constraints = 0
        self.lbound = np.array([0.01, 0.01])
        self.ubound = np.array([100, 100])
    
    def evaluate(self, x):
        return np.zeros(self.n_objectives)

class RE25:
    def __init__(self):
        self.problem_name = "RE25"
        self.n_objectives = 2
        self.n_variables = 3
        self.n_constraints = 0
        self.lbound = np.array([0.01, 0.01, 0.01])
        self.ubound = np.array([100, 100, 100])
    
    def evaluate(self, x):
        return np.zeros(self.n_objectives)

class RE31:
    def __init__(self):
        self.problem_name = "RE31"
        self.n_objectives = 3
        self.n_variables = 3
        self.n_constraints = 0
        self.lbound = np.array([0.01, 0.01, 0.01])
        self.ubound = np.array([100, 100, 100])
    
    def evaluate(self, x):
        return np.zeros(self.n_objectives)

class RE32:
    def __init__(self):
        self.problem_name = "RE32"
        self.n_objectives = 3
        self.n_variables = 4
        self.n_constraints = 0
        self.lbound = np.array([0.01, 0.01, 0.01, 0.01])
        self.ubound = np.array([100, 100, 100, 100])
    
    def evaluate(self, x):
        return np.zeros(self.n_objectives)

class RE33:
    def __init__(self):
        self.problem_name = "RE33"
        self.n_objectives = 3
        self.n_variables = 4
        self.n_constraints = 0
        self.lbound = np.array([0.01, 0.01, 0.01, 0.01])
        self.ubound = np.array([100, 100, 100, 100])
    
    def evaluate(self, x):
        return np.zeros(self.n_objectives)

class RE34:
    def __init__(self):
        self.problem_name = "RE34"
        self.n_objectives = 3
        self.n_variables = 5
        self.n_constraints = 0
        self.lbound = np.array([0.01, 0.01, 0.01, 0.01, 0.01])
        self.ubound = np.array([100, 100, 100, 100, 100])
    
    def evaluate(self, x):
        return np.zeros(self.n_objectives)

class RE37:
    def __init__(self):
        self.problem_name = "RE37"
        self.n_objectives = 3
        self.n_variables = 4
        self.n_constraints = 0
        self.lbound = np.array([0.01, 0.01, 0.01, 0.01])
        self.ubound = np.array([100, 100, 100, 100])
    
    def evaluate(self, x):
        return np.zeros(self.n_objectives)

class RE61:
    def __init__(self):
        self.problem_name = "RE61"
        self.n_objectives = 6
        self.n_variables = 4
        self.n_constraints = 0
        self.lbound = np.array([0.01, 0.01, 0.01, 0.01])
        self.ubound = np.array([100, 100, 100, 100])
    
    def evaluate(self, x):
        return np.zeros(self.n_objectives)
