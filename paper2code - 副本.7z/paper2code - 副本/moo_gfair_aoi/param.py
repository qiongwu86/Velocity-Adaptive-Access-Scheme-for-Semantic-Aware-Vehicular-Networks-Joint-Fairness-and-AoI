import numpy as np

params = {
    'p_v': [0.1, 0.2, 0.3],  # 发射功率极小
    'h_v': 1.0,  # 信道增益
    'sigma2': 0.1,  # 噪声功率极大
    'V_v': [2150,2100,2200],  # 车速
    'T_v_p': 5,  # 车辆v的最大目标数
    'd_v': [20, 30, 40],  # 距离极小
    'S_vk': np.random.rand(3, 3),
    'G_vk': np.random.rand(3, 3),
    'xi': np.random.rand(3),
    'a_vj': np.random.rand(3, 3),
    'b_vj': np.random.rand(3, 3),
    'RRI': 100,
    'nsh': 55,
    'bandwidth': 100e6,  # 带宽极大
    'rho': 1.0,
    'v_knots': [2000, 2100, 2200, 2800, 2900, 3000],
    'w_knots': [120, 100, 80, 40, 35, 25]
}