from pymoo.indicators.gd import GD
from pymoo.indicators.spacing import SpacingIndicator
from pymoo.visualization.scatter import Scatter
from pymoo.indicators.hv import Hypervolume
from pymoo.indicators.igd import IGD
import numpy as np
import os
import time
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
import matplotlib.ticker as ticker
# 计算 Epsilon Indicator (ε)
# 计算 Epsilon 指标
# def epsilon_indicator(F, PF):
#     """
#     计算 Epsilon 指标 (Epsilon Indicator).
#
#     参数:
#     - F (numpy.ndarray): 解集 (m x n)，每一行是一个解的目标值。
#     - PF (numpy.ndarray): 参考 Pareto 前沿 (k x n)，每一行是一个参考解的目标值。
#
#     返回:
#     - float: 计算出的 Epsilon 指标值。
#     """
#     epsilon = -np.inf
#     for f in F:
#         eps_for_f = np.min([np.max((p - f) / (f + 1e-9)) for p in PF])
#         epsilon = max(epsilon, eps_for_f)
#     return epsilon

def smooth_curve(n_evals, values):
    interp_func = interp1d(n_evals, values, kind='cubic', fill_value="extrapolate")
    smooth_values = interp_func(np.linspace(min(n_evals), max(n_evals), len(n_evals) * 5))  # 生成更多的点以平滑曲线
    return smooth_values
# Output results
def output(res, problemname, dimension, outputfile):


    timestamp = time.strftime("%Y%m%d_%H%M%S")
    outputfile = os.path.join(outputfile, problemname, f"d{dimension}", timestamp)
    os.makedirs(outputfile, exist_ok=True)

    X, F = res.opt.get("X", "F")
    hist = res.history

    n_evals = []  # function evaluations
    hist_F = []  # objective values in each generation

    for algo in hist:
        n_evals.append(algo.evaluator.n_eval)
        opt = algo.opt
        hist_F.append(opt.get("F"))

    #Hypervolume computation

    approx_ideal = F.min(axis=0)
    approx_nadir = F.max(axis=0)
    ref_point = np.array([1.1] * len(approx_nadir))

    metric_hv = Hypervolume(ref_point=ref_point, norm_ref_point=False, zero_to_one=True,
                            ideal=approx_ideal, nadir=approx_nadir)

    hv = [metric_hv.do(_F) for _F in hist_F]

    hv_file = os.path.join(outputfile, "hv_convergence.dat")
    with open(hv_file, "w") as f:
        for evals, val in zip(n_evals, hv):
            f.write(f"{evals} {val:.4f}\n")

    # IGD computation (optional)
    # Uncomment and replace `pf` with a proper Pareto front reference
    # n_samples = 100  # Number of points for the reference Pareto front
    # pf = np.linspace(approx_ideal, approx_nadir, n_samples)
    # metric_igd = IGD(pf, zero_to_one=True)
    #
    # igd = [metric_igd.do(_F) for _F in hist_F]
    #
    # igd_file = os.path.join(outputfile, "igd_convergence.dat")
    # with open(igd_file, "w") as f:
    #     for evals, val in zip(n_evals, igd):
    #         f.write(f"{evals} {val:.4f}\n")
    #
    # # GD computation (Generational Distance)
    # metric_gd = GD(pf, zero_to_one=True)  # 初始化GD指标
    # gd = [metric_gd.do(_F) for _F in hist_F]  # 计算GD值
    # gd = np.log1p(gd)
    #
    # gd = np.array(gd) * 0.5
    #
    # q1, q3 = np.percentile(gd, [25, 75])  # 计算第 25 和第 75 百分位数
    # iqr = q3 - q1  # 四分位间距
    # upper_bound = q3 + 1.5 * iqr  # 上限值
    # lower_bound = q1 - 1.5 * iqr  # 下限值
    # gd = np.clip(gd, lower_bound, upper_bound)  # 将值裁剪到合理范围内
    # gd_file = os.path.join(outputfile, "gd_convergence.dat")
    # with open(gd_file, "w") as f:
    #     for evals, val in zip(n_evals, gd):
    #         f.write(f"{evals} {val:.4f}\n")

    # Spread computation
    metric_Spacing = SpacingIndicator()  # 初始化Spread指标
    # Spacing = [metric_Spacing.do(_F) + 0.1 for _F in hist_F]  # 计算Spread值
    #
    # spread_file = os.path.join(outputfile, "spread_convergence.dat")
    # with open(spread_file, "w") as f:
    #     for evals, val in zip(n_evals, Spacing):
    #         f.write(f"{evals} {val:.4f}\n")
    # # Epsilon computation
    # epsilon_values = [epsilon_indicator(_F, pf)+1 for _F in hist_F]
    # epsilon_file = os.path.join(outputfile, "epsilon_convergence.dat")
    # with open(epsilon_file, "w") as f:
    #     for evals, val in zip(n_evals, epsilon_values):
    #         f.write(f"{evals} {val:.4f}\n")


    # # Save Pareto front
    # pf_file = os.path.join(outputfile, "PF_opt.dat")
    # np.savetxt(pf_file, F, fmt="%.4f")
    #
    # # Save decision variables
    # ps_file = os.path.join(outputfile, "PS_opt.dat")
    # np.savetxt(ps_file, X, fmt="%.4f")
    # 平滑曲线
    smooth_hv = smooth_curve(n_evals, hv)
    # smooth_igd = smooth_curve(n_evals, igd)
    # smooth_gd = smooth_curve(n_evals, gd)
    #smooth_spacing = smooth_curve(n_evals, Spacing)

    def apply_style(ax):
        # --- Remove spines and add gridlines
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_linewidth(1)

        ax.grid(ls="--", lw=0.5, color="#4E616C")

        # --- Adjust tickers and spine to match the style of our grid
        ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True, prune='lower', nbins=6))  # 限制刻度数量
        ax.xaxis.set_tick_params(length=2, labelsize=5)
        ax.yaxis.set_tick_params(length=2, labelsize=5)

        # --- Set labels and title
        ax.set_xlabel("Function Evaluations", fontsize=8)
        ax.set_ylabel("Metric Value", fontsize=8)

        # --- Set legend
        ax.legend(fontsize=8, frameon=True, framealpha=0.8, edgecolor="#4E616C", loc="upper right")

    # Plot Hypervolume Convergence
    fig, ax = plt.subplots(dpi=300)

    plt.plot(
        np.linspace(min(n_evals), max(n_evals), len(n_evals) * 5),
        smooth_hv,
        label="Hypervolume",
        color="blue",
        marker='o',
        markersize=2,  # 点标记的大小
        markerfacecolor='white',
        markeredgecolor='blue',
        markevery=80  # 每隔 20 个点标记一个
    )
    # plt.plot(
    #     np.linspace(min(n_evals), max(n_evals), len(n_evals) * 5),
    #     smooth_igd,
    #     label="IGD",
    #     color="orange",
    #     marker='s',
    #     markersize=2,
    #     markerfacecolor='white',
    #     markeredgecolor='orange',
    #     markevery=80
    # )
    # plt.plot(
    #     np.linspace(min(n_evals), max(n_evals), len(n_evals) * 5),
    #     smooth_gd,
    #     label="GD",
    #     color="green",
    #     marker='^',
    #     markersize=2,
    #     markerfacecolor='white',
    #     markeredgecolor='green',
    #     markevery=80
    # )
    # # plt.plot(
    # #     np.linspace(min(n_evals), max(n_evals), len(n_evals) * 5),
    # #     smooth_spacing,
    # #     label="Spacing",
    # #     color="purple",
    # #     marker='d',
    # #     markersize=2,
    # #     markerfacecolor='white',
    # #     markeredgecolor='purple',
    # #     markevery=80
    # # )
    #
    # 添加轴标签和样式
    plt.xlabel("Function Evaluations")
    plt.ylabel("Metric Value")
    plt.title("Convergence")
    # # plt.fill_between(n_evals, hv, igd, where=(np.array(hv) > np.array(igd)),
    # #                  color="blue", alpha=0.2, interpolate=True)
    # # plt.fill_between(n_evals, hv, igd, where=(np.array(hv) <= np.array(igd)),
    # #                  color="orange", alpha=0.2, interpolate=True)
    # # plt.fill_between(n_evals, hv, gd, where=(np.array(hv) <= np.array(igd)),
    # #                  color="red", alpha=0.2, interpolate=True)
    plt.legend()
    plt.grid()
    #apply_style(ax)
    hv_igd_plot = os.path.join(outputfile, "hv_igd_convergence.pdf")
    plt.savefig(hv_igd_plot,bbox_inches='tight')
    plt.show()

    # # Plot Pareto Front
    # epsilon = 1e-6
    # F += epsilon * np.random.random(F.shape)
    # #Scatter(title="Pareto Front").add(F).save(os.path.join(outputfile, "PF_plot.png"))
    # plot = Scatter(title="Pareto Surface", plot_3d=True, angle=(30, 45))
    # plot.add(F, mode="plot_trisurf", cmap="viridis", alpha=0.9)  # 使用 cmap 参数
    #
    # plot.save(os.path.join(outputfile, "Pareto_Surface.png"))
    # plot.show()