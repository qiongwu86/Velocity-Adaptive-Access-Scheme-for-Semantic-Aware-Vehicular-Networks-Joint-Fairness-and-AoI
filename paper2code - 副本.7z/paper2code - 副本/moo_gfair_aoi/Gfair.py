import math
import numpy as np
from param import *
import cvxpy as cp
N_v=3

RRI=100
nsc=5
Nr=100
C_Ca=50
N_Ca=5
def delta_vj(w, v, j, ):
    P_O = 1
    P_SHO = 1

    W_v, W_j = w[v], w[j]
    P_O = (W_v + W_j + 1) / (1000 *2 * RRI)
    N_sh = (W_v + 1) * (W_j + 1) / (W_v + W_j + 1)  # 公式 14
    # 计算 δ^j_COL (公式 12)
    # W_i, W_j = x[i], x[j]
    # P_O = 2*(W_i + W_j + 1) / (1000 + 2 * self.RRI)  # 公式 12 中的 P_O
    #
    #
    #
    # N_sh = (W_i + 1) **2 / (2*W_i + 1)

    P_SHO = (N_sh * nsc / Nr) ** 2   # 公式 13

        # 冲突概率 δ^j_COL
    delta_vj=P_O*P_SHO*C_Ca/(N_Ca)**2
    #delta_vj = P_O * P_SHO * C_Ca / N_Ca) / 10000


    return delta_vj




def grad_delta_vj(w,v,j ):
    """
    计算 δ_{v,j}(w) 对 w 的梯度（即偏导数）
    """
    w_v, w_j = w[v], w[j]
    A = w_v + 1
    B = w_j + 1
    D = w_v + w_j + 1
    c_delta=N_Ca**2 *Nr**2 *RRI/(nsc**2 *C_Ca)
    # 对 w_v 和 w_j 求偏导数
    d_delta_wv = 2 * B * A * (B * D - A * (B + 1)) / (D ** 3 * c_delta)
    d_delta_wj = 2 * A * B * (A * D - B * (A + 1)) / (D ** 3 * c_delta)

    return [d_delta_wv, d_delta_wj]


def compute_a_b(w_prev, v,j, c1=1.0):
    """
    计算 a_{v,j}^{(t)} 和 b_{v,j}^{(t)}，用于G_fair的近似
    """
    # 计算 δ_{v,j}(w)
    delta = delta_vj(w_prev, v, j)
    #print('delta_vj',delta )
    # 计算梯度
    grad = grad_delta_vj(w_prev, v, j)

    # 计算 a_{v,j}^{(t)} 和 b_{v,j}^{(t)}
    a_vj = -grad[0] / (1 - delta)
    b_vj = -grad[1] / (1 - delta)

    return a_vj, b_vj

# a=delta_vj([25,50,75], 1, 2, )
# b=grad_delta_vj([25,50,75], 1, 2, )
# print(a,b)

def calculate_Gfair(w,v, w_prev, params ):
    """
    计算车辆 v 的 G_fair 值（近似），输入 w_old 和车辆索引 v。

    参数:
        v: 当前车辆的索引
        w_old: 上一轮的选择窗口（包含所有车辆的窗口向量）
        c1: 常数参数
        Nv: 总车辆数量（默认为 3）
        params: 参数字典，包含额外需要的参数
    返回:
        G_fair_v: 车辆 v 的 G_fair 近似值
    """

    # 提取参数
    p_v = params['p_v']
    h_v = params['h_v']
    sigma2 = params['sigma2']
    V_v = params['V_v']
    T_v_p = params['T_v_p']
    d_v = params['d_v']
    S_vk = params['S_vk']
    G_vk = params['G_vk']
    rho = params['rho']

    # 计算分子：\sum_{k=1}^{T_v^p} \xi (S_{vk}, G_{vk})
    #sum_xi = np.sum(xi * S_vk[v, :] * G_vk[v, :])

    def calculate_h(v):
        """
        计算信道增益 h(t)
        :param i: 车辆索引
        :return: 信道增益
        """
        h_prev = 1  # 初始化上一时刻的信道增益
        e_t = np.random.normal(0, 1)  # 高斯噪声
        h_t = rho * h_prev + e_t * np.sqrt(1 - rho ** 2)
        return h_t

    # 计算分母：V_v * \log_2(1 + (p_v * h_v * d_v^{-\partial}) / sigma^2)
    log_term = np.log2(1 + (p_v[v] * calculate_h(v) * d_v[v] ** (-1)) / sigma2)   # log2(x) = ln(x)/ln(2)
    log_term = log_term ** 2

    # 计算指数项：\exp(- (c1 + \sum_{j \ne v} a_{v,j}^{(t)} (w_v - w_v^{(t)}) + b_{v,j}^{(t)} (w_j - w_j^{(t)})))
    total_avj = 0
    total_bvj = 0
    for j in range(N_v):
        if j!= v:
            #print('compute_a_b(w_prev, v, j)[0]',compute_a_b(w_prev, v, j)[0])
            total_avj += compute_a_b(w_prev, v, j)[0]*(w[v]-w_prev[v])

            total_bvj += compute_a_b(w_prev, v, j)[1]*(w[j]-w_prev[j])
    #print('total_avj',total_avj)
    # 计算c1
    c1=0
    for j in range(N_v):
        delta=delta_vj(w_prev,v,j)
        c1+= np.log(abs(1 - delta))
        c1= abs(c1)

    exp_term = (c1 + total_avj + total_bvj)
    sum_xi=0.95
    #print('exp_term',exp_term)
    #print('log_term', log_term)
    # 计算最终的 G_fair_v
    cons=(sum_xi / (V_v[v] * (log_term)**2))
    log_cons=np.log(cons)
    #G_fair_v = cons * cp.exp(exp_term)
    #print("log_cons",log_cons)
    #print("2*exp_term", 2*exp_term)
    #print("2*exp_term", 2 * exp_term)
    #G_fair_v = log_cons - 2*exp_term
    G_fair_v = cons/ (math.e ** exp_term)


    # print("w:", w, type(w))
    # print("w_prev:", w_prev, type(w_prev))
    # print("compute_a_b(w_prev, v, j):", compute_a_b(w_prev, v, j))
    # print("total_avj, total_bvj:", total_avj, total_bvj)
    # print("exp_term:", exp_term)
    # print("type(exp_term):", type(exp_term))
    v_factor = params['V_v'][v] / 2400
    #G_fair_v *= (1.0 + 0.5 * v_factor)  # 速度影响系数


    return G_fair_v


