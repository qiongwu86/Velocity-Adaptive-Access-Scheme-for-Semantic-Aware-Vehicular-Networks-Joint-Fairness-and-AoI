import numpy as np
import random
#import cupy as cp
import cvxpy as cp
from param import params

paramss = params
#print("paramss:", paramss)
#print("paramss type:", type(paramss))
def calculate_h(paramss):
    """
    计算信道增益 h(t)
    :param i: 车辆索引
    :return: 信道增益
    """
    #print(type(params), params)
    rho = paramss['rho']
    h_prev = 1  # 初始化上一时刻的信道增益
    e_t = np.random.normal(0, 1)  # 高斯噪声
    h_t = rho * h_prev + e_t * np.sqrt(1 - rho ** 2)
    return h_t

def calculate_bitrate(v,paramss):
        # 计算分母：V_v * \log_2(1 + (p_v * h_v * d_v^{-\partial}) / sigma^2)
    bandwidth=paramss['bandwidth']
    p_v = paramss['p_v']
    sigma2 = paramss['sigma2']
    d_v = paramss['d_v']
    log_term = np.log2(1 + (p_v[v] * calculate_h(paramss) * d_v[v] ** (-1)) / sigma2)
    return log_term
N_v=3

tp = 0.1  # 极小基础延迟
tfa = 0.01  # 极小tfa

c1 = [None] * N_v
c2 = [None] * N_v
c3 = [None] * N_v

c_bit= 500
def compute_c():
    for i in range(N_v):
        c1[i] = (tp + tfa + calculate_bitrate(i, params)/c_bit) / 20  # 再缩放
        c2[i] = 3*(tp + tfa + calculate_bitrate(i, params)/c_bit) / 20
        c3[i] = random.uniform(1e-6, 5e-6)  # 极小c3
    return c1,c2,c3
c1,c2,c3=compute_c()
print("c",c1,c2,c3)

def compute_A1(w,k):

    A1=(w[k]+c2[k])*(1-c3[k]*(w[k]+c1[k]))

    return A1

def compute_grad_A1(w,k):

    grad_A1=-2*c3[k]*w[k]-c3[k]*c2[k]-c3[k]*c1[k]+1

    return grad_A1

def compute_A2(w):
    a = 0
    for i in range(N_v):
        a += (w[i]+c1[i])/((w[i]+c2[i])*(1-c3[i]*(w[i]+c1[i])))
    A2 = 1+a

    return A2

def compute_grad_A2(w):
    grad_A2=0
    for i in range(N_v):

        grad_A2 += (c3[i]*w[i]**2+(2*c3[i]*c1[i]+c3[i]*c2[i])*w[i]+c2[i]-c1[i]+c3[i]*c1[i]**2)/((w[i]+c2[i])*(1-c3[i]*(w[i]+c1[i])))**2

    return grad_A2
def compute_A0(w,k):
    A0=compute_A1(w,k)*compute_A2(w)
    return A0

def compute_A(w,w_prev,k):
    A0=compute_A0(w_prev,k)
    #print("A0",A0)
    A1 = compute_A1(w_prev,k)
    #print("A1", A1)
    grad_A1 = compute_grad_A1(w_prev,k)
    A2 = compute_A2(w_prev)
    grad_A2 = compute_grad_A2(w_prev)
    grad_A=  grad_A1*A2 +A1*grad_A2

    A= A0+(grad_A)*(w[k]-w_prev[k])
    #print("A",A)

    return A

def compute_B(w,w_t):
    # 1. 定义 f_s 和导数
    def f_s(w,k):
        u = 1 / (w[k] + c1[k]) - 1 / c3[k]
        v = w[k] + c2[k]
        return v * u ** 2

    def grad_f_s(w,k):
        u = 1 / (w[k] + c1[k]) - 1 / c3[k]
        v = w[k] + c2[k]
        du = -1 / (w[k] + c1[k]) ** 2
        dv = 1
        return dv * u ** 2 + 2 * v * u * du

    # 2. 定义 g_k 和导数
    def g_k(w,k):
        a = w[k] + c2[k]
        b = 1 / (w[k] + c1[k]) - 1 / c3[k]
        return a * b

    def grad_g_k(w,k):
        a = w[k] + c2[k]
        b = 1 / (w[k] + c1[k]) - 1 / c3[k]
        da = 1
        db = -1 / (w[k] + c1[k]) ** 2
        return da * b + a * db

    # 3. 计算 N_F 和 g_k 向量
    def N_F(w):
        g_vals = np.array([g_k(w,k) for k in range(N_v)])
        return 1 + np.sum(1 / g_vals), g_vals

    # 4. 计算线性近似函数值和梯度
    def linear_approx_h_inv(w, w_t):
        """
        计算 1 / (N_F(w) * f_s(w_s)) 在 w_t 点处的线性近似

        w: 当前变量向量 (np.array)
        w_t: 线性化点 (np.array)
        s: 当前关注的索引
        c1[k],c2[k],c3[k]: 常数
        """
        #
        #f_t[s] = f_s(w[s])
        #f_s_grad_t[s] = grad_f_s(w[s])
        N_F_t, g_vals_t = N_F(w_t)
        grad_g_vals_t = np.array([grad_g_k(w,k) for k in range(N_v)])

        # 计算线性近似系数
        #B_t = 1 / (N_F_t * f_s_t)
        B=0
        # 对w_s的系数

        def compute_grad1(w,k):

            coef_ws1 = - grad_f_s(w,k) / (N_F_t * (f_s(w,k) ** 2))
            return coef_ws1

        def compute_grad2(w):
            coef_ws2=0
            for i in range(N_v):

                coef_ws2 += 1/(N_F_t**2 * f_s(w, i)) * (grad_g_k(w, i)/g_k(w, i)**2)

            return coef_ws2
        #原本函数值
        f_t = np.zeros(N_v)
        for i in range(N_v):
            # 原本函数值
            f_t[i] = f_s(w_t,i)

            # 线性近似值
            B += 1/ (N_F_t * f_t[i]) + (compute_grad1(w_t,i) + compute_grad2(w_t) )*(w[i]-w_t[i])




        return B

    B= linear_approx_h_inv(w,w_t)
    #print("B",B)
    return B


def compute_aoi(w,w_prev):
    aoi=0
    for i in range(N_v):
        aoi+=compute_A(w,w_prev,i)+compute_B(w,w_prev)
    # 直接返回aoi/N_v，目标函数中最小化它即可
    return aoi/N_v






