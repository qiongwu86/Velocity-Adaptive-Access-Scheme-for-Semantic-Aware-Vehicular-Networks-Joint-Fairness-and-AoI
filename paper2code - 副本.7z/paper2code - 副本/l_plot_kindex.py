import os
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker as ticker
from matplotlib import font_manager

# 设置更专业的字体和样式
plt.style.use('seaborn-v0_8-whitegrid')
mpl.rcParams['font.family'] = ['Times New Roman', 'DejaVu Sans', 'Arial']
mpl.rcParams['font.size'] = 11
mpl.rcParams['axes.linewidth'] = 1.2
mpl.rcParams['axes.labelsize'] = 12
mpl.rcParams['xtick.labelsize'] = 10
mpl.rcParams['ytick.labelsize'] = 10
mpl.rcParams['legend.fontsize'] = 10
mpl.rcParams['figure.dpi'] = 300
mpl.rcParams['savefig.dpi'] = 300
mpl.rcParams['savefig.bbox'] = 'tight'

# 数据设置 - 分为三组：SCA、LLM和Standard，每组只包含obs数据
x = [22.5, 23, 23.5, 24, 24.5, 25, 25.5, 26]

# SCA方法数据 - 只包含obs
sca_data = {
    #'Line1': [0.090, 0.0894, 0.0892, 0.0890, 0.0885, 0.088, 0.087, 0.0864],
    'Line2': [0.094, 0.0934, 0.0921, 0.0915, 0.091, 0.0906, 0.0901, 0.0895],
    'Line3': [0.092, 0.090, 0.0897, 0.0894, 0.0892, 0.089, 0.088, 0.087]
}

# LLM方法数据 - 只包含obs
llm_data = {
    #'Line1': [0.088, 0.0875, 0.0872, 0.0870, 0.0868, 0.0862, 0.0855, 0.0850],
    'Line2': [0.092, 0.0915, 0.0912, 0.0908, 0.0905, 0.0900, 0.0895, 0.0880],
    'Line3': [0.090, 0.0885, 0.0882, 0.0880, 0.0878, 0.0875, 0.0870, 0.0865]
}

# Standard方法数据 - 只包含obs
std_data = {
    #'Line1': [0.0875, 0.0858, 0.082, 0.078, 0.073, 0.069, 0.064, 0.058],
    'Line2': [0.089, 0.087, 0.084, 0.080, 0.075, 0.070, 0.066, 0.060],
    'Line3': [0.087, 0.085, 0.083, 0.076, 0.071, 0.065, 0.060, 0.054]
}

# 将三组数据整合到一个字典中
data = {
    'SCA': sca_data,
    'LLM-MO': llm_data,
    'Standard': std_data
}
# 创建更大的画布以提供更好的视觉效果
fig, ax = plt.subplots(figsize=(6.4, 4.8), dpi=300)

# 更专业的颜色方案 - 每种方法使用不同颜色
method_colors = {
    "SCA": "#2E86C1",      # 蓝色 - SCA方法
    "LLM-MO": "#ED7D31",      # 橙色 - LLM方法
    "Standard": "#28B463"  # 绿色 - 标准方法
}

# 车辆区分使用不同的线型
vehicle_line_styles = {
    "Line2": "-",           # 实线 - Line2
    "Line3": (0, (5, 3))    # 虚线 - Line3
}

# 每种方法使用不同的标记，图例中将显示不同形状以便区分
method_markers = {
    "SCA": "o",      # 圆形 - SCA
    "LLM-MO": "s",   # 方形 - LLM-MO
    "Standard": "^"  # 三角 - Standard
}

# 绘制折线图
for method_name, method_data in data.items():
    color = method_colors[method_name]

    for vehicle_name, vehicle_data in method_data.items():
        linestyle = vehicle_line_styles[vehicle_name]

        # 观测值线
        ax.plot(x, vehicle_data,
                color=color,
                linestyle=linestyle,
                marker=method_markers[method_name],
                markersize=7,
                markerfacecolor="white",
                markeredgecolor=color,
                markeredgewidth=2,
                linewidth=2.5,
                alpha=0.9,
                label=f'{method_name} {vehicle_name}',
                zorder=3)

# 改进的样式设置 - 显示所有边框
ax.spines['top'].set_visible(True)
ax.spines['right'].set_visible(True)
ax.spines['left'].set_linewidth(1.2)
ax.spines['bottom'].set_linewidth(1.2)
ax.spines['top'].set_linewidth(1.2)
ax.spines['right'].set_linewidth(1.2)
ax.spines['left'].set_color('#2C3E50')
ax.spines['bottom'].set_color('#2C3E50')
ax.spines['top'].set_color('#2C3E50')
ax.spines['right'].set_color('#2C3E50')

# 更精细的网格设置
ax.grid(True, linestyle='--', linewidth=0.8, alpha=0.6, color='#BDC3C7', zorder=1)
ax.set_axisbelow(True)

# 坐标轴设置，增加更好的标签
ax.set_xlabel("Average Speed (m/s)", fontsize=13, fontweight='bold', color='#2C3E50')
ax.set_ylabel("Fairness Index", fontsize=13, fontweight='bold', color='#2C3E50')

# 改进刻度设置
ax.tick_params(axis='both', labelsize=11, colors='#2C3E50', width=1.2)
ax.tick_params(axis='x', length=6, which='major')
ax.tick_params(axis='y', length=6, which='major')

# 设置x轴刻度和标签
ax.set_xticks(x)
ax.set_xticklabels([str(val) for val in x])

# 专业的图例设置 - 分两列排列，放置在左下角
legend = ax.legend(
    ncol=2,
    fontsize=7,
    frameon=True,
    framealpha=0.95,
    edgecolor='#2C3E50',
    fancybox=True,
    shadow=True,
    loc='lower left',
    bbox_to_anchor=(0.02, 0.02),
    handlelength=3.5,  # 增加图例线条长度，更好显示线型
    handletextpad=0.8,
    columnspacing=1.2,
    numpoints=1,       # 确保标记点显示
    scatterpoints=1    # 确保散点显示
)
legend.get_frame().set_facecolor('#F8F9FA')
legend.get_frame().set_linewidth(1.2)

# 手动调整图例中的线型显示效果
for line in legend.get_lines():
    line.set_linewidth(2.5)  # 确保图例中线条足够粗以显示线型差异

# # 添加标题，使图表更完整
# ax.set_title('Fairness Index Vs Average Speed', 
#              fontsize=14, fontweight='bold', color='#2C3E50', pad=20)

# 保存图片，支持多种格式
desktop_path = os.path.expanduser("~") + "/Desktop"

# 调整布局，确保所有元素都能完整显示
plt.tight_layout()

# 保存高质量图片
plt.savefig(os.path.join(desktop_path, "4kindex_optimized.pdf"),
            format='pdf',
            transparent=False, 
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            dpi=300)

plt.savefig(os.path.join(desktop_path, "4kindex_optimized.png"),
            format='png',
            transparent=False, 
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            dpi=300)

print("图表已保存到桌面：kindex_optimized.pdf 和 kindex_optimized.png")

plt.show()