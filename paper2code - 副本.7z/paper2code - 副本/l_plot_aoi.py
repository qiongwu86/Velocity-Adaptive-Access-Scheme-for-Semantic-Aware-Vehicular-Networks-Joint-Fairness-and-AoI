import os
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker as ticker
from matplotlib import font_manager

# 设置更专业的字体和样式
plt.style.use('seaborn-v0_8-whitegrid')
mpl.rcParams['font.family'] = ['Times New Roman', 'DejaVu Sans', 'Arial']
mpl.rcParams['font.size'] = 11
mpl.rcParams['axes.linewidth'] = 1.2
mpl.rcParams['axes.labelsize'] = 12
mpl.rcParams['xtick.labelsize'] = 10
mpl.rcParams['ytick.labelsize'] = 10
mpl.rcParams['legend.fontsize'] = 10
mpl.rcParams['figure.dpi'] = 300
mpl.rcParams['savefig.dpi'] = 300
mpl.rcParams['savefig.bbox'] = 'tight'

# 设置数据
x = [22.5, 23, 23.5, 24, 24.5, 25, 25.5, 26]
speed_labels = [str(val) for val in x]  # 转换为字符串标签

# AOI数据
data = {
    "SCA": [65.4, 66, 67.4, 67.8, 69.2, 70.4, 72.5, 76.3],      # 本方法AOI 
    "LLM-MO": [66.4, 68.3, 69.7, 71.8, 71.9, 73.4, 75.7, 78.9],   # LLM-MO方法 
    "Standard": [102.3, 102.5, 104.3, 106.5, 107.2, 107.4, 109.5, 111.5]  # 原本AOI
}

# 创建更大的画布以提供更好的视觉效果
fig, ax = plt.subplots(figsize=(6.4, 4.8), dpi=300)

# 更专业的颜色方案
colors = {
    "SCA": "#2E86C1",      # 专业蓝色
    "LLM-MO": "#28B463",    # 专业绿色
    "Standard": "#E74C3C"   # 专业红色
}

# 绘制柱状图设置
bar_width = 0.25  # 调整宽度以适应三个柱子
index = np.arange(len(x))

# 绘制柱状图，增强视觉效果
bars_sca = ax.bar(index - bar_width, data["SCA"], bar_width, 
                   color=colors["SCA"], 
                   edgecolor='white',
                   linewidth=1.5,
                   alpha=0.9,
                   label="SCA",
                   zorder=3)

bars_llm = ax.bar(index, data["LLM-MO"], bar_width,
                  color=colors["LLM-MO"],
                  edgecolor='white', 
                  linewidth=1.5,
                  alpha=0.9,
                  label="LLM-MO",
                  zorder=3)

bars_standard = ax.bar(index + bar_width, data["Standard"], bar_width,
                       color=colors["Standard"],
                       edgecolor='white', 
                       linewidth=1.5,
                       alpha=0.9,
                       label="Standard",
                       zorder=3)

# # 为柱状图添加数值标签
# for i, (ours_val, std_val) in enumerate(zip(data["Ours"], data["Standard"])):
#     # Ours标签
#     ax.text(i - bar_width/2, ours_val + 1, f'{ours_val}',
#             ha='center', va='bottom', fontsize=9, fontweight='bold')
#     # Standard标签  
#     ax.text(i + bar_width/2, std_val + 1, f'{std_val:.1f}',
#             ha='center', va='bottom', fontsize=9, fontweight='bold')

# 改进的样式设置 - 显示所有边框
ax.spines['top'].set_visible(True)
ax.spines['right'].set_visible(True)
ax.spines['left'].set_linewidth(1.2)
ax.spines['bottom'].set_linewidth(1.2)
ax.spines['top'].set_linewidth(1.2)
ax.spines['right'].set_linewidth(1.2)
ax.spines['left'].set_color('#2C3E50')
ax.spines['bottom'].set_color('#2C3E50')
ax.spines['top'].set_color('#2C3E50')
ax.spines['right'].set_color('#2C3E50')

# 更精细的网格设置
ax.grid(True, linestyle='--', linewidth=0.8, alpha=0.6, color='#BDC3C7', zorder=1)
ax.set_axisbelow(True)

# 坐标轴设置，增加更好的标签
ax.set_xlabel("Average Speed (m/s)", fontsize=13, fontweight='bold', color='#2C3E50')
ax.set_ylabel("Average AoI (ms)", fontsize=13, fontweight='bold', color='#2C3E50')

# 改进刻度设置
ax.tick_params(axis='both', labelsize=11, colors='#2C3E50', width=1.2)
ax.tick_params(axis='x', length=6, which='major')
ax.tick_params(axis='y', length=6, which='major')

# 设置x轴刻度和标签
ax.set_xticks(index)
ax.set_xticklabels(speed_labels)

# 设置y轴范围，确保底部边框完整显示
y_min = min(min(data["SCA"]), min(data["LLM-MO"]), min(data["Standard"]))
y_max = max(max(data["SCA"]), max(data["LLM-MO"]), max(data["Standard"]))
y_range = y_max - y_min
# 给底部留出一些空间，避免柱子遮挡边框
y_min_expanded = 0  # 底部向下扩展5%，但不低于0
y_max_expanded = 150   # 顶部向上扩展10%
ax.set_ylim(y_min_expanded, y_max_expanded)

# 确保坐标轴底部边框在柱子之上显示
ax.axhline(y=y_min_expanded, color='#2C3E50', linewidth=1.2, zorder=5)

# 重新设置底部边框，确保它在最上层
ax.spines['bottom'].set_zorder(5)

# 格式化y轴刻度
ax.yaxis.set_major_formatter(ticker.FormatStrFormatter('%.1f'))

# 专业的图例设置 - 放置在左下角
legend = ax.legend(
    fontsize=10,
    frameon=True,
    framealpha=0.95,
    edgecolor='#2C3E50',
    fancybox=True,
    shadow=True,
    loc='lower left',
    bbox_to_anchor=(0.02, 0.02),
    handlelength=2.5,
    handletextpad=0.8
)
legend.get_frame().set_facecolor('#F8F9FA')
legend.get_frame().set_linewidth(1.2)

# # 添加标题，使图表更完整
# ax.set_title(' AoI Vs Average Speed', 
#              fontsize=14, fontweight='bold', color='#2C3E50', pad=20)

# 保存图片，支持多种格式
desktop_path = os.path.expanduser("~") + "/Desktop"

# 调整布局，确保所有元素都能完整显示
plt.tight_layout()

# 保存高质量图片
plt.savefig(os.path.join(desktop_path, "3aoi_optimized.pdf"),
            format='pdf',
            transparent=False, 
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            dpi=300)

plt.savefig(os.path.join(desktop_path, "3aoi_optimized.png"),
            format='png',
            transparent=False, 
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            dpi=300)


plt.show()
