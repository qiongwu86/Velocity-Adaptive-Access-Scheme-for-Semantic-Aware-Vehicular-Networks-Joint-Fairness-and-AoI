import math


from Gfair import *
from aoi import *
# cp.settings.ENABLE_NONCONVEX = True
from param import params
import matplotlib
matplotlib.use('TkAgg')  # 或者 'Qt5Agg'，根据需要选择
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter

import numpy as np
import cvxpy as cp
w_max=150
w_min=20

#print("params",params)
mu = np.ones(N_v+1)

# 权重设置：先让正则主导，AOI和Gfair权重可适当减小
for i in range(N_v):
    mu[i] = 2  # Gfair权重
mu[N_v] = 1   # AOI权重
#mu[N_v]= 0.001
#for i in
# C= 10000
# Range=200
# Band=10e5
# B_t=20000

#print(type(params), params)


# SCA +
def SCA_solver(w0, params, N_v, max_iter=500, tol=None ):
    V_v = params['V_v']
    w_prev = np.array(w0)
    history_w = [w_prev.copy()]
    history_objective=[]
    history_gfair_diff = []  # 记录每次迭代的Gfair差值
    V_v = np.array(params['V_v'])
    v_k = params['v_knots']
    w_k = params['w_knots']
    w_t = np.interp(V_v, v_k, w_k)  
    penalty = 30.0  # penalty适中，避免正则主导
    # 权重设置：让AOI/Gfair主导收敛
    for i in range(N_v):
        mu[i] = 10  # Gfair权重
    mu[N_v] = 2   # AOI权重
    #mu[N_v]= 0.001
    #for i in
    # C= 10000
    # Range=200
    # Band=10e5
    # B_t=20000

    # 先计算初始w0的目标函数值
    Gfair_approx0 = [calculate_Gfair(w_prev, k, w_prev, params) for k in range(N_v)]
    total_Gfair0 = sum(Gfair_approx0)
    avg_Gfair0 = total_Gfair0 / N_v
    gfair_diff_0 = [Gfair_approx0[v] - avg_Gfair0 for v in range(N_v)]
    history_gfair_diff.append(gfair_diff_0)  # 记录初始的Gfair差值
    objective_terms1_0 = sum([mu[v] * abs(Gfair_approx0[v] - avg_Gfair0) for v in range(N_v)])
    objective_terms2_0 = mu[N_v] * compute_aoi(w_prev, w_prev)
    reg_0 = penalty * np.sum((w_prev - w_t) ** 2)
    f0 = float(objective_terms1_0 + objective_terms2_0 + reg_0)
    history_objective.append(f0)
    converge_count = 0
    last_f = None
    for t in range(max_iter):
        w = cp.Variable(3)


        # L(x, mu) ≈ f(x_prev) + grad_f(x_prev)'(x - x_prev) + mu * h(x) - (rho/2) * h(x)^2
        # 这里我们用带惩罚项的Augmented Lagrangian形式提高收敛稳定性

        Gfair_approx= [None] * N_v  #近似后的Gfair
        total_Gfair=0
        for k in range(N_v):

            Gfair_approx[k] =calculate_Gfair(w, k, w_prev,params)
            #print(type(Gfair_approx[k]))

            #print('Gfair_approx[k]=',Gfair_approx[k])
            total_Gfair += Gfair_approx[k]
            #AOI1_approx = AOI1(x_prev) + grad_AOI1 @ (w - w_prev)
            #AOI2_approx = AOI1(x_prev) + grad_AOI1 @ (w - w_prev)
            #AOI_approx =AOI1_approx+AOI2_approx #近似后的detaK
            #total_AOI_approx+ =AOI_approx
        #avg_Gfair=C*Band**2/(Range*B_t**3)
        avg_Gfair=total_Gfair/N_v
        #print(avg_Gfair.args)
        #print('avg_Gfair',avg_Gfair)

        z = cp.Variable(N_v)  # 引入辅助变量 z
        objective_terms1 = 0
        for v in range(N_v):
            
            speed_weight = 0.1 * (params['V_v'][v] / max(params['V_v']))
            objective_terms1 += mu[v]*cp.sum(cp.abs(Gfair_approx[v]-avg_Gfair))
        # AOI 归一化，保证为正且量级合适
        objective_terms2 = mu[N_v]*compute_aoi(w,w_prev) * 0.1  # aoi缩放适中
        reg = penalty * cp.sum_squares(w - w_t)
        # 约束条件
        constraints = []
        for i in range(N_v):
            constraints += [
                w[i] <= w_max,
                w_min <= w[i]
            ]
        # 定义目标函数
        objective = objective_terms1 + objective_terms2 + reg
        prob = cp.Problem(cp.Minimize(objective), constraints)
        # 只保留一次 prob.solve()
        try:
            # 可选的求解器列表 (按优先级排序)：
            # 1. ECOS - 二阶锥规划专用，内点法
            # 2. OSQP - 二次规划专用，ADMM算法  
            # 3. SCS - 通用锥优化，操作员分离法
            # 4. CLARABEL - 新一代内点法求解器
            # 5. CVXOPT - 通用凸优化，内点法
            # 6. MOSEK - 商业求解器，高性能内点法
            # 7. GUROBI - 商业求解器，单纯形法+内点法
            # 8. CPLEX - 商业求解器，多种算法
            
            result = prob.solve()  # 默认使用ECOS
            # 获取实际使用的求解器信息
            if hasattr(prob, 'solver_stats') and prob.solver_stats:
                solver_name = prob.solver_stats.solver_name
                print(f"[INFO] 使用求解器: {solver_name}")
            else:
                print(f"[INFO] 使用默认求解器")
            if w.value is None:
                print(f"[ERROR] Solve failed at iteration {t + 1}. Status: {prob.status}")
                break
        except cp.error.SolverError as e:
            print(f"[ERROR] Solver threw exception at iteration {t + 1}: {str(e)}")
            break
        # 步长和w_new赋值放在try-except之后，确保prob已定义
        alpha=0.05  # 步长适中，收敛平稳
        w_new = (1 - alpha) * w_prev + alpha * w.value
        objective_new = float(prob.value)  # 明确保存数值
        history_w.append(w_new.copy())
        history_objective.append(objective_new)  # 只保存一次，且为float
        # # 收敛判断：连续10次f值变化小于tol
        # if last_f is not None and abs(objective_new - last_f) < tol:
        #     converge_count += 1
        #     if converge_count >= 10:
        #         print(f"Converged at iteration {t + 1} (f stable for 10 iterations)")
        #         break
        # else:
        #     converge_count = 0
        # last_f = objective_new
        # 收敛判断
        if np.linalg.norm(w_new - w_prev) < tol:
            converge_count += 1
            if converge_count >= 10:
                print(f"Converged at iteration {t + 1} (stable for 10 iterations)")
                break
        else:
            converge_count = 0  # 如果当前不满足条件，重置计数器

        w_prev = w_new
        # 计算并记录当前迭代的Gfair差值
        Gfair_vals = []
        gfair_diff_current = []
        history_gfair_diff = []
        for v in range(N_v):
            try:
                gfair_val = Gfair_approx[v].value
                avg_gfair_val = avg_Gfair.value
                diff_val = gfair_val - avg_gfair_val
                Gfair_vals.append(gfair_val)
                gfair_diff_current.append(diff_val)
            except:
                Gfair_vals.append(None)
                gfair_diff_current.append(None)
        
        history_gfair_diff.append(gfair_diff_current)  # 记录当前迭代的差值
        
        # 可选打印信息
        print(f"Iter {t + 1}: f={prob.value:.10f}, w={w_new},aoi={objective_terms2.value}")
        print(f"  Gfair_vals={Gfair_vals}")
        print(f"  avg_Gfair={avg_Gfair.value if hasattr(avg_Gfair, 'value') else avg_Gfair}")
        print(f"  Gfair_diff={gfair_diff_current}")
        #print("objective_terms1",objective_terms1.value)
    min_positive_f = None
    min_positive_idx = None
    # 跳过第一次迭代（初始w），从第二次开始筛选
    for idx, fval in enumerate(history_objective[1:], start=1):
        if fval > 0:
            if min_positive_f is None or fval < min_positive_f:
                min_positive_f = fval
                min_positive_idx = idx
    if min_positive_f is not None:
        print(f"最小正目标值: {min_positive_f:.10f}，对应w: {history_w[min_positive_idx]}")
    else:
        print("没有正的目标值")
    

    
    return w_new, np.array(history_w), history_objective

# 初始化并运行
w0 = [150, 150, 150]  # 
N_v = 3  # 假设有 3 个目标
w_opt, path_w, history_objective = SCA_solver(w0, params=params,N_v=3,tol=1e-5)

#print("Optimal w:", w_opt)
#print("Final min/max bound violation:", np.any(w_opt < w_min) or np.any(w_opt > w_max))



# plt.figure(figsize=(10, 4))
# for i in range(3):
#     plt.plot(path_w[:, i], label=f"w[{i}] path")
# plt.title("SCA: Variable paths")
# plt.xlabel("Iteration")
# plt.ylabel("w value")
# plt.legend()
# plt.grid(True)
# plt.show()

# # 画目标函数f的迭代路径
# plt.figure(figsize=(12, 8))

# # 第一个子图：目标函数迭代路径
# plt.subplot(2, 1, 1)
# plt.plot(history_objective[1:], label='Objective f')  # 跳过w0的f值
# plt.gca().yaxis.set_major_formatter(ScalarFormatter(useOffset=False))  # 强制y轴普通数字
# plt.title('Objective f Iteration Path')
# plt.xlabel('Iteration')
# plt.ylabel('f value')
# plt.legend()
# plt.grid(True)

# plt.show()

