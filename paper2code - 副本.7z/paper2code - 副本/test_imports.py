#!/usr/bin/env python3
import sys
print("Python executable:", sys.executable)
print("Python version:", sys.version)

try:
    import openai
    print("OpenAI imported successfully!")
    print("OpenAI version:", openai.__version__)
except ImportError as e:
    print("Failed to import OpenAI:", e)
