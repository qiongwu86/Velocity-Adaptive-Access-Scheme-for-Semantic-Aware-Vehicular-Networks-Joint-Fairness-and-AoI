import os
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker as ticker
from matplotlib import font_manager

# 设置更专业的字体和样式
plt.style.use('seaborn-v0_8-whitegrid')
mpl.rcParams['font.family'] = ['Times New Roman', 'DejaVu Sans', 'Arial']
mpl.rcParams['font.size'] = 11
mpl.rcParams['axes.linewidth'] = 1.2
mpl.rcParams['axes.labelsize'] = 12
mpl.rcParams['xtick.labelsize'] = 10
mpl.rcParams['ytick.labelsize'] = 10
mpl.rcParams['legend.fontsize'] = 10
mpl.rcParams['figure.dpi'] = 300
mpl.rcParams['savefig.dpi'] = 300
mpl.rcParams['savefig.bbox'] = 'tight'

# 数据设置
x = [22.5, 23, 23.5, 24, 24.5, 25, 25.5, 26]
y_SCA =   [65.4, 66, 67.4, 67.8, 69.2, 70.4, 72.5, 76.3]       # SCA
y_moead = [69.5, 71.8, 73.2, 74.1, 76.6, 78.4, 81.4, 83.8]  # MOEA/D
y_nsga2 = [68.2, 68.9, 70.9, 71.3, 73.8, 74.4, 77.3, 80.2]     # NSGA-II
y_nsga3 = [67.7, 68.4, 69.9, 70.9, 72.4, 73.5, 76.9, 79.5]     # NSGA-III
y_spea2 = [70.2, 72.4, 74.8, 78.1, 79.8, 82.5, 83.9, 85.2]     # SPEA2
y_llmmo = [66.4, 68.3, 69.7, 71.8, 71.9, 73.4, 75.7, 78.9]     # LLM-MO 
# 创建更大的画布以提供更好的视觉效果
fig, ax = plt.subplots(figsize=(6.4, 4.8), dpi=300)

# 更专业的颜色方案
colors = ['#2E86C1', '#E74C3C', '#28B463', '#F39C12', '#9B59B6', '#1ABC9C']  # 专业配色，调整顺序让LLM-MO使用红色
bar_width = 0.12  # 调整柱宽适配6组
x_ticks = np.arange(len(x))

# 绘制分组柱状图，增强视觉效果
bars_sca = ax.bar(x_ticks - 2.5*bar_width, y_SCA, bar_width, 
                  color=colors[0], edgecolor='white', linewidth=1.5,
                  alpha=0.9, label='SCA', zorder=3)
bars_llm = ax.bar(x_ticks - 1.5*bar_width, y_llmmo, bar_width, 
                  color=colors[1], edgecolor='white', linewidth=1.5,
                  alpha=0.9, label='LLM-MO', zorder=3)
bars_moead = ax.bar(x_ticks - 0.5*bar_width, y_moead, bar_width, 
                    color=colors[2], edgecolor='white', linewidth=1.5,
                    alpha=0.9, label='MOEA/D', zorder=3)
bars_nsga2 = ax.bar(x_ticks + 0.5*bar_width, y_nsga2, bar_width, 
                    color=colors[3], edgecolor='white', linewidth=1.5,
                    alpha=0.9, label='NSGA-II', zorder=3)
bars_nsga3 = ax.bar(x_ticks + 1.5*bar_width, y_nsga3, bar_width, 
                    color=colors[4], edgecolor='white', linewidth=1.5,
                    alpha=0.9, label='NSGA-III', zorder=3)
bars_spea2 = ax.bar(x_ticks + 2.5*bar_width, y_spea2, bar_width, 
                    color=colors[5], edgecolor='white', linewidth=1.5,
                    alpha=0.9, label='SPEA2', zorder=3)

# 改进的样式设置 - 显示所有边框
ax.spines['top'].set_visible(True)
ax.spines['right'].set_visible(True)
ax.spines['left'].set_linewidth(1.2)
ax.spines['bottom'].set_linewidth(1.2)
ax.spines['top'].set_linewidth(1.2)
ax.spines['right'].set_linewidth(1.2)
ax.spines['left'].set_color('#2C3E50')
ax.spines['bottom'].set_color('#2C3E50')
ax.spines['top'].set_color('#2C3E50')
ax.spines['right'].set_color('#2C3E50')

# 更精细的网格设置
ax.grid(True, linestyle='--', linewidth=0.8, alpha=0.6, color='#BDC3C7', zorder=1)
ax.set_axisbelow(True)

# 坐标轴设置，增加更好的标签
ax.set_xlabel("Average Speed (m/s)", fontsize=13, fontweight='bold', color='#2C3E50')
ax.set_ylabel("Average AoI (ms)", fontsize=13, fontweight='bold', color='#2C3E50')

# 改进刻度设置
ax.tick_params(axis='both', labelsize=11, colors='#2C3E50', width=1.2)
ax.tick_params(axis='x', length=6, which='major')
ax.tick_params(axis='y', length=6, which='major')

# 设置x轴刻度和标签
ax.set_xticks(x_ticks)
ax.set_xticklabels([str(val) for val in x])

# 设置y轴范围，确保底部边框完整显示
y_values_all = y_SCA + y_moead + y_nsga2 + y_nsga3 + y_spea2 + y_llmmo
y_min, y_max = min(y_values_all), max(y_values_all)
# 给底部留出一些空间，避免柱子遮挡边框
y_range = y_max - y_min
y_min_expanded = 0  # 底部向下扩展5%
y_max_expanded = y_max + 0.1 * y_range   # 顶部向上扩展10%
ax.set_ylim(y_min_expanded, y_max_expanded)

# 确保坐标轴底部边框在柱子之上显示
ax.axhline(y=y_min_expanded, color='#2C3E50', linewidth=1.2, zorder=5)

# 重新设置底部边框，确保它在最上层
ax.spines['bottom'].set_zorder(5)

# 格式化y轴刻度
ax.yaxis.set_major_formatter(ticker.FormatStrFormatter('%.1f'))



# 专业的图例设置
legend = ax.legend(
    fontsize=9,
    frameon=True,
    framealpha=0.95,
    edgecolor='#2C3E50',
    fancybox=True,
    shadow=True,
    loc='lower right',
    ncol=3,  # 改为3列以适应6种方法
    handlelength=2.0,
    handletextpad=0.6,
    columnspacing=1.0
)
legend.get_frame().set_facecolor('#F8F9FA')
legend.get_frame().set_linewidth(1.2)

# # 添加标题，使图表更完整
# ax.set_title('Average AoI Comparison Across Methods', 
#              fontsize=14, fontweight='bold', color='#2C3E50', pad=20)

# 保存图片，支持多种格式
desktop_path = os.path.expanduser("~") + "/Desktop"

# 调整布局，确保所有元素都能完整显示
plt.tight_layout()

# 保存高质量图片
plt.savefig(os.path.join(desktop_path, "6method_aoi_optimized.pdf"),
            format='pdf',
            transparent=False, 
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            dpi=300)

plt.savefig(os.path.join(desktop_path, "6method_aoi_optimized.png"),
            format='png',
            transparent=False, 
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            dpi=300)

print("AOI对比图表已保存到桌面：method_aoi_optimized.pdf 和 method_aoi_optimized.png")

plt.show()