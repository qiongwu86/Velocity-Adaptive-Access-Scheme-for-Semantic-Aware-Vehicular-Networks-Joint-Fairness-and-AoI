import os
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import ScalarFormatter  # Added for scientific notation

# Define file paths and labels
files = ['fairness/llm1.txt', 'fairness/moead1.txt', 'fairness/nsga.txt', 'fairness/nsga3.txt', 'fairness/spea2.txt']
labels = ['Ours', 'MOEA/D', 'NSGA-II', 'NSGA-III', 'SPEA2']

# Read and preprocess data
raw_data = []
for file in files:
    x, y = [], []
    with open(file, 'r') as f:
        for line in f:
            if line.strip():
                a, b = line.split()
                x.append(int(a))
                y.append(float(b))
    raw_data.append((np.array(x), np.array(y)))

# Align x-axis using interpolation
x_common = raw_data[0][0]
interpolated_data = []
for x, y in raw_data:
    y_interp = np.interp(x_common, x, y, left=y[0], right=y[-1])
    interpolated_data.append((x_common.copy(), y_interp))

# Configure plot parameters
fig, ax = plt.subplots(dpi=300, figsize=(6.4, 4.8))
markers = ['o', 's', 'D']

# Plot interpolated data
for idx in range(len(interpolated_data)):
    x, y = interpolated_data[idx]
    plt.plot(x, y, markersize=1, linewidth=2, label=labels[idx])

# Axis labels and formatting
plt.xlabel('Iteration', fontsize=12)
plt.ylabel('Hypervolume (HV)', fontsize=12)
plt.grid(True, alpha=0.4)
plt.legend(loc='lower right', frameon=True, fontsize=8)

# Set axis limits and scientific notation
max_x = max([x[-1] for x, _ in interpolated_data])
plt.xlim(left=0, right=70000)

# Scientific notation implementation
ax.xaxis.set_major_formatter(ScalarFormatter(useMathText=True))
ax.ticklabel_format(axis='x', style='sci', scilimits=(0, 0))
ax.xaxis.offsetText.set_fontsize(12)  # Adjust exponent font size

# Save and display
desktop_path = os.path.expanduser("~") + "/Desktop"
plt.savefig(os.path.join(desktop_path, "5.pdf"), transparent=True, bbox_inches='tight')
plt.tight_layout()
plt.show()